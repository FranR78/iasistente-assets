/*
 * iAsistente → Séneca (basada en la extensión Evaluanda → Séneca): panel flotante en Séneca que aplica el paquete recibido
 * de iAsistente. Con «Empezar», recorre Séneca él solo por el menú:
 *   1. Grupos de alumnos/as: lee los grupos del docente y pregunta en cuál volcar;
 *      luego, en Mis alumnos y alumnas, coteja el alumnado y deja emparejar a mano.
 *   2. Parámetros del cuaderno: crea la categoría si no existe.
 *   3. Actividades: elige grupo y evaluación y crea las actividades que falten.
 *   4. Cuaderno: empareja al alumnado y pone las notas por criterio (comprobadas).
 * Nunca borra nada.
 */
(function () {
  'use strict';
  if (window.top !== window) return;

  // ---------- utilidades ----------
  var $ = function (sel, raiz) { return (raiz || document).querySelector(sel); };
  var campo = function (n) { return $('[name="' + n + '"]'); };
  function norm(s) {
    return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/[^a-z0-9ñ]+/g, ' ').trim();
  }
  /** Nombre comparable sin importar el orden («Apellidos, Nombre» = «Nombre Apellidos»). */
  function claveNombre(s) { return norm(s).split(' ').filter(Boolean).sort().join(' '); }
  // Códigos LOMLOE («LCL.4.1.1») y de FP («SSC. 1. a»); se comparan sin espacios («SSC.1.a»).
  function codigoDe(texto) {
    var m = /^\s*([A-ZÑ]{2,6}(?:\s?\.\s?\d+){1,4}(?:\s?\.\s?[a-zñ](?![a-zñ]))?)(?=[.\s)-]|$)/.exec(texto || '');
    return m ? m[1].replace(/\s+/g, '') : '';
  }
  function ddmmaaaa(d) { return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); }
  function aFecha(s) {
    var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s || '');
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }
  function cambiar(el) { el.dispatchEvent(new Event('change', { bubbles: true })); }
  function textoSel(sel) { return sel && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex].text : ''; }
  function opcionPorTexto(sel, f) { return [].filter.call(sel.options, function (o) { return f(o.text); })[0] || null; }

  // ---------- puente con el mundo de la página (seneca-main.js) ----------
  var seq = 0, esperas = {};
  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (ev.source !== window || !d || d.iasSenecaMain !== 'res' || d.ext !== chrome.runtime.id || !esperas[d.id]) return;
    var e = esperas[d.id]; delete esperas[d.id];
    if (d.ok) e.ok(d.data); else e.ko(new Error(d.error));
  });
  function pagina(op, args) {
    return new Promise(function (ok, ko) {
      var id = 'c' + (++seq);
      esperas[id] = { ok: ok, ko: ko };
      // Si Séneca recarga la página a mitad, la respuesta no llega: no se espera para siempre.
      setTimeout(function () {
        if (esperas[id]) { delete esperas[id]; ko(new Error('Séneca no ha respondido (¿ha cambiado de pantalla?).')); }
      }, 120000);
      window.postMessage({ iasSenecaMain: 'cmd', ext: chrome.runtime.id, id: id, op: op, args: args || {} }, '*');
    });
  }

  // ---------- estado (chrome.storage.local) ----------
  // Instalada desde la Chrome Web Store (Chrome le añade update_url) o a mano. Si
  // conviven las dos, la manual se aparta y avisa para que la quiten.
  var OFICIAL = !!chrome.runtime.getManifest().update_url, avisoVisto = false;
  if (OFICIAL) document.documentElement.setAttribute('data-ias-seneca-oficial', '1');
  function apartada() { return !OFICIAL && document.documentElement.hasAttribute('data-ias-seneca-oficial'); }
  var E = { paquete: null, progreso: { acts: {} }, log: [], flujo: null, grupo: null, grupos: {}, resultado: null, abierto: false };
  var CLAVES = ['paquete', 'progreso', 'log', 'flujo', 'grupo', 'grupos', 'mapa', 'catReal', 'catIdx', 'cortos', 'instrumentoDefecto', 'cotejado', 'resultado', 'abierto', 'sel', 'modo'];
  function cargar(cb) {
    chrome.storage.local.get(CLAVES, function (r) {
      E.paquete = r.paquete || null;
      E.progreso = r.progreso || { acts: {} };
      E.log = r.log || [];
      E.resultado = r.resultado || null;
      E.flujo = r.flujo || null;
      E.grupo = r.grupo || null;
      E.grupos = r.grupos || {};
      E.mapa = r.mapa || {};
      E.catReal = r.catReal && typeof r.catReal === 'object' ? r.catReal : {};
      E.catIdx = r.catIdx || 0;
      E.cortos = r.cortos || {}; // clase#nombre → descripción corta con la que se creó (no se borra)
      E.instrDef = r.instrumentoDefecto || ''; // opciones de la extensión
      E.cotejado = r.cotejado || '';
      E.abierto = r.abierto !== false;
      E.sel = r.sel || {};             // {índice de actividad: false} = no subirla
      E.modo = r.modo || 'notas';      // interruptor Notas / Observaciones (lo comparte observaciones.js)
      cb();
    });
  }
  function guardar() {
    chrome.storage.local.set({ progreso: E.progreso, log: E.log.slice(-60), resultado: E.resultado,
      flujo: E.flujo, grupo: E.grupo, grupos: E.grupos, mapa: E.mapa, catReal: E.catReal, catIdx: E.catIdx, cortos: E.cortos, cotejado: E.cotejado, abierto: E.abierto, sel: E.sel });
  }
  function log(msg) {
    E.log.push(new Date().toLocaleTimeString().slice(0, 5) + ' ' + msg);
    guardar(); pintar();
  }
  /** Pasa a otra fase del recorrido (reinicia la cuenta de intentos). */
  function fase(f, extra) { E.flujo = f ? Object.assign({ fase: f, intentos: 0 }, extra || {}) : null; guardar(); }
  /** Detiene el recorrido con un aviso; «Reintentar» lo reanuda en la misma fase. */
  function parar(msg) { if (E.flujo) { E.flujo.parado = msg; guardar(); } log('✗ ' + msg); }

  // ---------- pantallas de Séneca ----------
  function pantalla() {
    if (campo('D_CATACTEVA') && campo('C_CATACTEVA')) return 'formCategoria';
    if (campo('D_ACTEVA') && campo('S_ACTEVA')) return 'formActividad';
    if (campo('TOTAL_FILAS') && campo('F_ENTREGA') && campo('X_GRUALUPROMAT')) return 'cuaderno';
    if (campo('X_GRUALUPROMAT') && campo('X_CATACTEVA')) return 'actividades';
    if ($('[name^="OpEmergenteTB_CATACTEVA"]') || campo('L_HACEUSO')) return 'parametros';
    if ($('select[name="X_OFERTAMATRIG"]')) return 'alumnos';
    if ($('[name^="T_DESCPERS_"]') || $('#id_Carga_de_grupos')) return 'grupos';
    return '';
  }
  /**
   * Navega por el menú lateral de Séneca: abre el apartado `seccion` (p. ej.
   * «Cuaderno de clase») y pulsa su opción `opcion`. Requiere la pestaña
   * Alumnado del menú; si no está, avisa.
   */
  function irMenu(seccion, opcion) {
    var tog = [].filter.call(document.querySelectorAll('a.nav-link[data-toggle="collapse"]'),
      function (a) { return norm(a.textContent) === norm(seccion); })[0];
    var ul = tog && document.getElementById((tog.getAttribute('href') || '').slice(1));
    var link = ul && [].filter.call(ul.querySelectorAll('a.nav-link'),
      function (a) { return norm(a.textContent) === norm(opcion); })[0];
    if (!link) return parar('No encuentro «' + seccion + ' → ' + opcion + '» en el menú. Abre la pestaña Alumnado del menú de Séneca y pulsa Reintentar.');
    link.click();
  }
  /**
   * Mayor «Orden» de la tabla de categorías (para poner la nueva a continuación,
   * respetando los huecos que el docente deja para intercalar). Se lee la columna
   * «Orden»; si no se encuentra, cualquier celda numérica.
   */
  function ordenMaximo() {
    var max = 0, th = [].filter.call(document.querySelectorAll('th'), function (x) { return norm(x.textContent) === 'orden'; })[0];
    var celdas = th ? [].map.call(th.closest('table').querySelectorAll('tbody tr'), function (tr) { return tr.children[th.cellIndex]; })
      : document.querySelectorAll('td');
    [].forEach.call(celdas, function (td) {
      var t = td ? td.textContent.trim() : '';
      if (/^\d{1,4}$/.test(t)) max = Math.max(max, +t);
    });
    return max;
  }
  /** Primer mensaje de error visible de Séneca en la pantalla ('' si no hay). */
  function errorSeneca() {
    return [].map.call(document.querySelectorAll('[class*="error" i], [class*="alert" i], [id*="error" i], [class*="mensaje" i]'), function (e) {
      return e.offsetParent !== null ? e.textContent.replace(/\s+/g, ' ').trim() : '';
    }).filter(function (t) { return t && t.length < 300; })[0] || '';
  }
  /** Textos de las celdas de las tablas de la pantalla (para ver qué existe ya). */
  function textosTabla() {
    var s = {};
    [].forEach.call(document.querySelectorAll('td'), function (td) { var t = norm(td.textContent); if (t) s[t] = 1; });
    return s;
  }
  /** Grupos del docente (pantalla Grupos de alumnos/as): {desc, texto, n}. */
  function sinAlumnos(t) { return String(t || '').replace(/\s*\/\s*\d+\s*alumn\S*$/i, ''); }
  function leerGrupos() {
    return [].map.call(document.querySelectorAll('[name^="T_DESCPERS_"]'), function (inp) {
      var td = inp.closest('tr') && inp.closest('tr').querySelector('td');
      var texto = td ? td.textContent.replace(/\s+/g, ' ').trim() : '';
      var m = /(\d+)\s*alumn/i.exec(texto);
      // Sin «descripción personal» (muchos docentes no la rellenan) vale la de Séneca.
      return { desc: inp.value.trim() || sinAlumnos(texto), propia: !!inp.value.trim(), texto: texto, n: m ? +m[1] : null };
    }).filter(function (g) { return g.desc; });
  }
  /**
   * Opción del grupo elegido en un combo de Séneca: la que se llama igual que su
   * descripción o su fila y, si no (sin descripción propia Séneca lo nombra con
   * otras palabras), la que más palabras comparte con la fila, si no hay empate.
   */
  function opcionGrupo(sel, valeEmpate) {
    var d = norm(E.grupo.desc), x = norm(sinAlumnos(E.grupo.texto)), tx = x.split(' ');
    // Palabras de la materia (de iAsistente): desempatan entre materias del mismo grupo.
    var area = norm((E.paquete.grupo || {}).area).split(' ').filter(function (w) { return w.length > 3; });
    var ops = [].filter.call(sel.options, function (o) { return norm(o.text); });
    // Sin descripción personal, los combos repiten la fila entera («… / 4ºB / 25 alumnos\as»).
    var full = norm(E.grupo.texto);
    var exacta = ops.filter(function (o) { var n = norm(o.text); return n === d || n === x || n === full; })[0];
    if (exacta) return exacta;
    var mejor = null, top = 0, empate = false;
    ops.forEach(function (o) {
      var ws = norm(o.text).split(' ');
      var c = ws.filter(function (w) { return tx.indexOf(w) >= 0; }).length +
        area.filter(function (w) { return ws.indexOf(w) >= 0; }).length / 10;
      if (c > top) { top = c; mejor = o; empate = false; } else if (c === top) empate = true;
    });
    // En «Mis alumnos y alumnas» un empate es el mismo grupo con varias materias
    // (mismo alumnado; el cotejo lo confirma): vale la primera.
    return top >= 1 && (!empate || valeEmpate) ? mejor : null;
  }
  /** Para el aviso de «no encuentro el grupo»: las opciones que sí hay. */
  function opcionesTexto(sel) {
    return [].map.call(sel.options, function (o) { return o.text.trim(); }).filter(Boolean).slice(0, 8).join(' | ');
  }
  /** Alumnado listado en «Mis alumnos y alumnas» (nombre tal como lo muestra Séneca). */
  function leerAlumnos() {
    return [].map.call(document.querySelectorAll('[id^="ALUMNO_"]'), function (d) {
      return ((d.querySelector('p') || d).textContent || '').replace(/\s+/g, ' ').trim();
    }).filter(Boolean);
  }
  /** Parecido entre dos nombres: palabras en común (para proponer emparejamientos). */
  function parecido(a, b) {
    var pa = claveNombre(a).split(' '), pb = claveNombre(b).split(' ');
    return pa.filter(function (x) { return x.length > 2 && pb.indexOf(x) >= 0; }).length;
  }
  /**
   * Coteja el alumnado de Séneca con el del paquete. Los que coinciden por nombre
   * (sin importar el orden) no necesitan nada; los demás pasan a la pantalla de
   * emparejar, con una propuesta por parecido.
   */
  /** Firma «grupo + alumnado del paquete»: si no cambia, no hace falta volver a cotejar. */
  /** Grupo de Séneca elegido para esta clase de iAsistente (se recuerda por clase). */
  function claveClase() { return E.paquete.evalId || E.paquete.clase; }
  function grupoDeClase() { return E.paquete && E.grupos[claveClase()] || null; }
  /**
   * Grupo de Séneca que más se parece a la clase de iAsistente: mismo número de
   * alumnado, mismo nombre de grupo (4ºB), misma materia (sigla LCL, MAT… o el
   * nombre) y mismo curso. Índice del mejor si destaca; -1 si no hay claro.
   */
  function sugerirGrupo(gs) {
    var P = E.paquete, G = P.grupo || {};
    var clase = norm(G.clase), area = norm(G.area).split(' ').filter(function (w) { return w.length > 2; });
    var ini = area.map(function (w) { return w[0]; }).join(''), curso = (/\d+/.exec(G.curso || '') || [])[0];
    var mejor = -1, top = 0, empate = false;
    gs.forEach(function (g, k) {
      var t = norm(g.texto + ' ' + g.desc), s = 0;
      if (g.n === P.alumnos.length) s += 3; else if (g.n != null && Math.abs(g.n - P.alumnos.length) <= 2) s += 1;
      if (clase && (' ' + t + ' ').indexOf(' ' + clase + ' ') >= 0) s += 3;
      var siglas = g.texto.split('/').map(function (x) { return norm(x); }).filter(function (x) { return /^[a-z]{2,6}$/.test(x); });
      if (area.length && (siglas.some(function (x) { return ini.indexOf(x) === 0 && x.length > 1 || x.indexOf(ini) === 0 && ini.length > 1 || x === area[0].slice(0, x.length); }) ||
        area.some(function (w) { return t.indexOf(w) >= 0; }))) s += 3;
      if (curso && (/\d+/.exec(g.texto) || [])[0] === curso) s += 1;
      if (g.propia && norm(P.clase).indexOf(norm(g.desc)) === 0) s += 3; // su descripción personal es el nombre de la clase
      if (s > top) { top = s; mejor = k; empate = false; } else if (s === top) empate = true;
    });
    return top >= 4 && !empate ? mejor : -1;
  }
  function firmaCotejo() { return E.grupo.desc + '#' + E.paquete.alumnos.join('|'); }
  function cotejar(nombresS) {
    var P = E.paquete, claveE = {}, usadosS = {};
    P.alumnos.forEach(function (n, i) { claveE[claveNombre(n)] = i; });
    nombresS.forEach(function (n) { if (claveE[claveNombre(n)] != null) usadosS[n] = 1; });
    var sinS = nombresS.filter(function (n) { return !usadosS[n]; });
    var porS = {}; nombresS.forEach(function (n) { if (usadosS[n]) porS[claveNombre(n)] = 1; });
    var sinE = [];
    P.alumnos.forEach(function (n, i) {
      if (porS[claveNombre(n)]) return;
      var mejor = '', pm = 0;
      sinS.forEach(function (s2) { var p = parecido(n, s2); if (p > pm) { pm = p; mejor = s2; } });
      sinE.push({ i: i, sel: mejor });
    });
    E.mapa = {};
    if (!sinE.length && !sinS.length) {
      log('✓ Alumnado: los ' + P.alumnos.length + ' coinciden con Séneca.');
      E.cotejado = firmaCotejo();
      return fase('irActs');
    }
    log('Alumnado: ' + (P.alumnos.length - sinE.length) + ' coinciden; ' + sinE.length + ' por emparejar.');
    fase('cotejo', { sinS: sinS, sinE: sinE });
  }
  /**
   * Clave de categoría: sin espacios, puntos ni ceros a la izquierda, y con el
   * prefijo unificado por familias («UD.01» = «Unidad 1» = «UD01»;
   * «SdA 1» = «SA01» = «SIAP 1» = «Situación de aprendizaje 1»). SdA y UD no se mezclan.
   */
  function claveCat(s) {
    return norm(s).replace(/ /g, '').replace(/\d+/g, function (n) { return String(+n); })
      .replace(/^(situaciondeaprendizaje|situacionaprendizaje|siap|sda|sa)(?=\d)/, 'sda')
      .replace(/^(unidaddidactica|unidad|ud|u)(?=\d)/, 'ud');
  }
  /** ¿Este texto de Séneca es la categoría del paquete (por nombre o abreviatura, o la ya elegida)? */
  /** Categoría de la actividad i: cada una trae la suya (su Unidad); si no, la del paquete. */
  function catDe(i) { var a = E.paquete.actividades[i] || {}; return a.categoria || E.paquete.categoria; }
  /** Categoría con la que se trabaja ahora: la de la actividad que toca crear. */
  function catCur() { return catDe(E.catIdx || 0); }
  /** Nombre que tiene en Séneca (el del paquete mientras no se sepa). */
  function catNombre(c) { return E.catReal[c.descripcion] || c.descripcion; }
  /** Para el panel: la categoría si es una sola, o cuántas son. */
  function catsTexto() {
    var vistas = {};
    E.paquete.actividades.forEach(function (a, i) { vistas[catDe(i).descripcion] = catDe(i); });
    var ks = Object.keys(vistas);
    return ks.length === 1 ? catNombre(vistas[ks[0]]) : ks.length + ' categorías';
  }
  function esCategoria(t) {
    var c = catCur(), k = claveCat(t);
    if (!k) return false;
    if (k === claveCat(catNombre(c)) || k === claveCat(c.descripcion) || (!!c.abreviatura && k === claveCat(c.abreviatura))) return true;
    // Misma Unidad y módulo («UD 1. SSC - …») aunque el resto del nombre difiera.
    var m = /^(?:ud|unidad|u) ?(\d+)\b/.exec(norm(t));
    return !!(m && c.ud && c.sigla && +m[1] === +c.ud && (' ' + norm(t) + ' ').indexOf(' ' + norm(c.sigla) + ' ') >= 0);
  }
  /** En Parámetros: nombre de la categoría ya existente equivalente a la del paquete ('' si no hay). */
  function categoriaExistente() {
    var fila = [].filter.call(document.querySelectorAll('tr'), function (tr) {
      var td = tr.querySelectorAll('td');
      return td.length > 1 && (esCategoria(td[0].textContent) || esCategoria(td[1].textContent));
    })[0];
    return fila ? fila.querySelector('td').textContent.replace(/\s+/g, ' ').trim() : '';
  }
  function categoriaEnCombo() {
    var sel = campo('X_CATACTEVA');
    return sel ? opcionPorTexto(sel, esCategoria) : null;
  }
  /**
   * ¿Esta opción de Séneca es la evaluación del paquete («1ª Evaluación»)? Además del
   * nombre exacto acepta variantes de otras etapas (Bachillerato): «Evaluación 1»,
   * «Primera evaluación», «1ª Evaluación (Bachillerato)»…
   */
  function esEval(t) {
    var n = norm(t), q = norm(E.paquete.evaluacion);
    if (n.indexOf(q) === 0) return true;
    var num = (/\d+/.exec(q) || [])[0];
    if (!num || n.indexOf('evaluacion') < 0) return false;
    var ord = { 1: 'primera', 2: 'segunda', 3: 'tercera' }[num];
    var m = /\d+/.exec(n);
    return m ? m[0] === num : !!(ord && n.indexOf(ord) >= 0);
  }
  function evalOk() {
    var sel = campo('X_CONVCENTRO');
    return !sel || esEval(textoSel(sel));
  }
  /**
   * Deja elegidos en la pantalla el grupo («Alumnado de») y la evaluación.
   * Devuelve true si ha cambiado algo (Séneca recarga: hay que esperar).
   */
  function asegurarFiltros() {
    var g = campo('X_GRUALUPROMAT');
    if (g) {
      var og = opcionGrupo(g);
      if (!og) { parar('No encuentro el grupo «' + E.grupo.desc + '» en «Alumnado de» (opciones: ' + opcionesTexto(g) + ').'); return true; }
      if (g.value !== og.value) { g.value = og.value; cambiar(g); return true; }
    }
    var ev = campo('X_CONVCENTRO');
    if (ev && !evalOk()) {
      var oe = opcionPorTexto(ev, esEval);
      if (oe) { ev.value = oe.value; cambiar(ev); return true; }
      // Sin la opción: Séneca puede estar cargándola; si no aparece, se para diciendo cuáles hay
      // (antes se esperaba hasta el «no responde como esperaba», sin pista del motivo).
      if (E.flujo && E.flujo.intentos > 15) parar('No encuentro la evaluación «' + E.paquete.evaluacion + '» en el desplegable de evaluación (opciones: ' + opcionesTexto(ev) + ').');
      return true;
    }
    return false;
  }
  /** ¿Se sube la actividad i? (elegida en el panel y no descartada al confirmar) */
  function incluida(i) { return E.sel[i] !== false && E.progreso.acts[i] !== 'omitida'; }
  /** Actividades de la tabla de Séneca (pantalla Actividades): [{desc, corto}]. */
  function filasActividades() {
    var out = [];
    [].forEach.call(document.querySelectorAll('table'), function (t) {
      var ths = [].map.call(t.querySelectorAll('th'), function (h) { return norm(h.textContent); });
      var iD = ths.indexOf('actividad'), iC = ths.indexOf('descripcion corta');
      if (iD < 0) return;
      [].forEach.call(t.querySelectorAll('tr'), function (tr) {
        var td = tr.querySelectorAll('td');
        if (td.length <= iD) return;
        var limpio = function (x) { return x ? x.textContent.replace(/\s+/g, ' ').trim() : ''; };
        out.push({ desc: limpio(td[iD]), corto: iC >= 0 ? limpio(td[iC]) : '' });
      });
    });
    return out;
  }
  /** ¿Esta fila de Séneca es la actividad a? Por descripción, por corta o por la descripción recortada. */
  function esLaMisma(a, f) {
    var d = norm(f.desc), n = norm(a.nombre), c = norm(f.corto), mio = a.corto || E.cortos[claveCorto(a)];
    if (d && d === n) return true;
    if (c && mio && c === norm(mio)) return true;
    return d.length >= 15 && n.indexOf(d) === 0; // Séneca recorta la descripción larga («…Imagen 20 elem»)
  }
  function actividadExiste(i, tabla, filas) {
    if (E.progreso.acts[i]) return true;
    var a = E.paquete.actividades[i], f = (filas || []).filter(function (x) { return esLaMisma(a, x); })[0];
    if (f || tabla[norm(a.nombre)] || (a.corto && tabla[norm(a.corto)])) {
      E.progreso.acts[i] = 'existia';
      if (f && f.corto) E.cortos[claveCorto(a)] = f.corto; // para casar su columna en el cuaderno
    }
    return !!E.progreso.acts[i];
  }
  function siguienteActividad() {
    var tabla = textosTabla(), filas = filasActividades();
    for (var i = 0; i < E.paquete.actividades.length; i++) if (incluida(i) && !actividadExiste(i, tabla, filas)) return i;
    return -1;
  }
  /** Para confirmar: filas de Séneca parecidas a la actividad (posible duplicado), las más parecidas primero. */
  function parecidas(a, filas) {
    var n = norm(a.nombre);
    return filas.map(function (f, k) {
      var contiene = n.length >= 5 && (norm(f.desc).indexOf(n) >= 0 || norm(f.corto) === n) ? 2 : 0; // «Impacto» ⊂ «UD.1. Clima - Impacto»
      return { k: k, p: Math.max(parecido(a.nombre, f.desc), a.corto ? parecido(a.corto, f.corto) : 0, contiene) };
    })
      .filter(function (x) { return x.p >= 2; }).sort(function (x, y) { return y.p - x.p; }).map(function (x) { return x.k; });
  }
  /** Unidades (categorías) del paquete con sus actividades, en orden: [{c, ids}]. */
  function gruposCat() {
    var g = {}, orden = [];
    E.paquete.actividades.forEach(function (a, i) {
      var c = catDe(i).descripcion;
      if (!g[c]) { g[c] = []; orden.push(c); }
      g[c].push(i);
    });
    return orden.map(function (c) { return { c: c, ids: g[c] }; });
  }
  function llamar(fn) { pagina('llamar', { fn: fn }).catch(function (e) { parar(e.message); }); }

  // ---------- formularios ----------
  function rellenarCategoria() {
    var c = catCur();
    campo('D_CATACTEVA').value = c.descripcion.slice(0, campo('D_CATACTEVA').maxLength > 0 ? campo('D_CATACTEVA').maxLength : 100);
    // Abreviatura: sin espacios y como mucho 10 caracteres (límite de Séneca).
    var ca = campo('C_CATACTEVA'), max = Math.min(10, ca.maxLength > 0 ? ca.maxLength : 10);
    var abr = ca.value = (c.abreviatura || c.descripcion).replace(/\s+/g, '').slice(0, max);
    var nd = $('[name="L_DIARIA"][value="N"]'); if (nd) nd.checked = true;
    var vs = $('[name="L_VIGENTE"][value="S"]'); if (vs) vs.checked = true;
    // «Orden de presentación» (obligatorio, sin repetir): la siguiente decena tras la
    // última (la de la tabla o la que propone Séneca, que es «última + 1»), desde 100.
    // Así quedan huecos para intercalar categorías sin renumerar: 208 → 210, 50 → 100.
    var or = campo('N_ORDENPRE');
    if (or) {
      var ultimo = Math.max(E.flujo.orden || 0, (+or.value || 1) - 1);
      or.value = String(Math.max(100, Math.floor(ultimo / 10) * 10 + 10));
    }
    log('Relleno la nueva categoría «' + c.descripcion + '» (' + abr + ') y la guardo.');
    fase('catTras', { abr: abr });
    llamar('aceptar');
  }
  /**
   * Descripción corta (la cabecera del cuaderno). Séneca la limita a pocos caracteres:
   * si al recortar choca con la de otra actividad del paquete, se acaba en « n».
   */
  function claveCorto(a) { return claveClase() + '#' + norm(a.nombre); }
  function cortoDe(i, max) {
    var P = E.paquete, a = P.actividades[i], base = a.corto || a.nombre, c = base.slice(0, max).trim();
    var choca = P.actividades.some(function (b, j) { return j !== i && norm((b.corto || b.nombre).slice(0, max)) === norm(c); });
    if (!choca) return c;
    var suf = ' ' + (i + 1);
    return base.slice(0, max - suf.length).trim() + suf;
  }
  /** Opción del combo de instrumentos que corresponde a `nombre`: igual, empieza igual o lo contiene. */
  function instrumentoEnCombo(sel, nombre) {
    var n = norm(nombre), ops = [].filter.call(sel.options, function (o) { return o.value !== '' && o.value !== '-1' && norm(o.text); });
    return ops.filter(function (o) { return norm(o.text) === n; })[0] ||
      ops.filter(function (o) { return norm(o.text).indexOf(n) === 0; })[0] ||
      ops.filter(function (o) { return norm(o.text).indexOf(n) >= 0; })[0] || null;
  }
  /** Mueve las opciones de una lista doble de Séneca: deja en _SEL solo las que cumplan `quedar`. */
  function listaDoble(nombre, quedar) {
    var can = campo(nombre + '_CAN'), sel = campo(nombre + '_SEL');
    if (!can || !sel) return 0;
    [].slice.call(sel.options).forEach(function (o) { if (!quedar(o.text)) can.appendChild(o); });
    [].slice.call(can.options).forEach(function (o) { if (quedar(o.text)) sel.appendChild(o); });
    return sel.options.length;
  }
  /** Rellena el formulario de nueva actividad en varios pasos (los combos recargan la página). */
  function rellenarActividad() {
    var idx = E.flujo.idx, a = E.paquete.actividades[idx], op = E.paquete.opciones || {};
    // a) Grupo, evaluación y categoría: cambiarlos recarga parte del formulario.
    if (asegurarFiltros()) return;
    var oc = categoriaEnCombo(), sc = campo('X_CATACTEVA');
    if (!oc) return parar('Falta la categoría «' + catCur().descripcion + '» en Séneca.');
    if (sc.value !== oc.value) { sc.value = oc.value; return cambiar(sc); }
    // b) «Contiene una calificación» con sistema numérico.
    var lc = campo('L_CHECK'), lcal = campo('L_CAL');
    if (lc && lc.checked) return lc.click();
    if (lcal && !lcal.checked) return lcal.click();
    var ss = campo('X_SISTCAL');
    if (ss && (ss.value === '-1' || ss.value === '')) {
      var on = opcionPorTexto(ss, function (t) { return /num[eé]rico/i.test(t); }) ||
        [].filter.call(ss.options, function (o) { return o.value !== '-1' && o.value !== ''; })[0];
      if (!on) return; // aún cargando
      ss.value = on.value; return cambiar(ss);
    }
    // b2) Instrumento de evaluación (obligatorio en FP): el de la actividad, el del
    // paquete o, si iAsistente no manda ninguno, el de las opciones de la extensión.
    var si = campo('X_INSEVACOMBAS');
    if (si) {
      var instr = a.instrumento || E.paquete.instrumento || E.instrDef || '';
      var oi = instr && instrumentoEnCombo(si, instr);
      if (!oi) {
        return parar('«' + a.nombre + '»: ' + (instr ? 'no encuentro el instrumento «' + instr + '»' : 'falta el instrumento de evaluación') +
          ' en Séneca (opciones: ' + opcionesTexto(si) + '). Elígelo en iAsistente o en las opciones de la extensión.');
      }
      if (si.value !== oi.value) { si.value = oi.value; return cambiar(si); }
    }
    // c) Textos y fecha (dentro de la evaluación).
    var d = campo('D_ACTEVA'), s = campo('S_ACTEVA');
    d.value = a.nombre.slice(0, d.maxLength > 0 ? d.maxLength : 100);
    s.value = cortoDe(idx, s.maxLength > 0 ? s.maxLength : 20);
    // «Detalle» (texto largo, opcional): el único <textarea> del formulario.
    var det = $('textarea[name="T_DETALLE"]') || $('textarea');
    if (det && a.detalle) det.value = a.detalle.slice(0, det.maxLength > 0 ? det.maxLength : 2000);
    E.cortos[claveCorto(a)] = s.value; guardar(); // para hallar luego su columna
    var ini = aFecha((campo('F_FECINICON_VAL') || {}).value), fin = aFecha((campo('F_FECFINCON') || {}).value);
    var f = aFecha(a.fecha) || new Date(), pedida = ddmmaaaa(f);
    if (ini && f < ini) f = ini;
    if (fin && f > fin) f = fin;
    campo('F_INICIO').value = ddmmaaaa(f);
    if (ddmmaaaa(f) !== pedida) log('⚠ «' + a.nombre + '»: ' + pedida + ' cae fuera de la evaluación; uso ' + ddmmaaaa(f) + '.');
    // d) Competencias específicas: son las que deciden qué criterios ofrece
    // Séneca. Se asignan las de los criterios (MAT.4.1.1 → MAT.4.1) y se pide
    // a Séneca que recargue las listas de criterios (cambioCompEsp).
    var opciones = function (n) {
      var c1 = campo(n + '_CAN'), c2 = campo(n + '_SEL');
      return [].slice.call(c1 ? c1.options : []).concat([].slice.call(c2 ? c2.options : []));
    };
    if (!E.flujo.comp) {
      var comps = opciones('X_COMESPLOMLOE');
      if (!comps.length) {
        // FP: el formulario ya trae los criterios y no tiene lista de competencias: no se espera.
        var esFP = !campo('X_COMESPLOMLOE_CAN') && !!campo('X_CRIEVACOMBAS_CAN');
        if (!esFP && E.flujo.intentos < 20) return;
        // FP: el formulario no lleva competencias específicas; se va directo a los criterios.
        log('«' + a.nombre + '»: sin competencias específicas en el formulario (FP); paso a los criterios.');
        E.flujo.comp = true; E.flujo.intentos = 0; guardar();
        return;
      }
      var compQ = {};
      a.criterios.forEach(function (c) { compQ[c.split('.').slice(0, -1).join('.')] = 1; });
      var casan = comps.some(function (o) { return compQ[codigoDe(o.text)]; });
      listaDoble('X_COMESPLOMLOE', function (t) { return !casan || !!compQ[codigoDe(t)]; });
      E.flujo.comp = true; E.flujo.intentos = 0; guardar();
      return llamar('cambioCompEsp');
    }
    // e) Criterios: se espera a que Séneca los cargue y se dejan solo los de la actividad.
    var quiero = {}; a.criterios.forEach(function (c) { quiero[c] = 1; });
    var todas = opciones('X_CRIEVACOMBAS');
    if (!todas.some(function (o) { return quiero[codigoDe(o.text)]; }) && E.flujo.intentos < 20) return;
    var n = listaDoble('X_CRIEVACOMBAS', function (t) { return !!quiero[codigoDe(t)]; });
    if (!n && !todas.length) {
      // Diagnóstico: qué listas dobles tiene este formulario (nombre, nº de opciones y la primera).
      var listas = [].map.call(document.querySelectorAll('select[name$="_CAN"], select[name$="_SEL"]'), function (x) {
        return x.name + ' (' + x.options.length + (x.options[0] ? ': ' + x.options[0].text.trim().slice(0, 30) : '') + ')';
      });
      return parar('«' + a.nombre + '»: no encuentro la lista de criterios. Listas del formulario: ' + (listas.join(' | ') || 'ninguna') + '.');
    }
    if (!n) {
      return parar('«' + a.nombre + '»: ningún criterio casa. Séneca tiene ' +
        todas.slice(0, 3).map(function (o) { return codigoDe(o.text) || o.text.slice(0, 25); }).join(', ') +
        '…; iAsistente envía ' + a.criterios.slice(0, 3).join(', ') + '…');
    }
    var faltan = a.criterios.filter(function (c) {
      return ![].some.call(campo('X_CRIEVACOMBAS_SEL').options, function (o) { return codigoDe(o.text) === c; });
    });
    if (faltan.length) log('⚠ «' + a.nombre + '»: Séneca no tiene ' + faltan.join(', '));
    // f) Todo el alumnado; opciones de familias.
    var parcial = campo('L_AFECTA_TODOS');
    if (parcial && parcial.checked) parcial.click();
    if (campo('L_MOSTRAR')) campo('L_MOSTRAR').checked = !!op.mostrar;
    if (campo('L_PUBLICAR_NOTA')) campo('L_PUBLICAR_NOTA').checked = !!op.publicar;
    fase('actTras', { idx: idx });
    llamar('aceptar');
  }

  // ---------- notas ----------
  var poniendo = false, avanceNotas = 0; // avanceNotas: fracción hecha (barra de progreso)
  var notaActual = null; // { act, j, n }: lo que se está calificando, para el panel
  // Para el panel: celdas hechas/total, inicio (estimar lo que queda), avance por actividad y última nota.
  var vivo = null; // { t0, hechas, total, porAct: { i: [hechas, total] }, ultima }
  async function ponerNotas() {
    if (poniendo) return;
    poniendo = true; pintar();
    try {
      var P = E.paquete, porClave = {}, tot = { guardadas: 0, iguales: 0, avisos: 0 };
      P.alumnos.forEach(function (n, i) { porClave[claveNombre(n)] = i; });
      var cuaderno = await pagina('actividadesCuaderno');
      // La cabecera puede ser el nombre largo, el corto (recortado) o llevar algo más.
      // 1) Por la descripción corta con la que se creó (exacta). 2) Si no se conoce, por
      // nombre, pero solo si la cabecera no vale también para otra actividad: con
      // cabeceras recortadas («UD.1. Clima -») dos actividades pueden parecer la misma
      // columna, y entonces no se escribe nada.

      var casa = function (t, a) {
        var na = norm(a.nombre);
        return t && (t === na || (t.length >= 3 && (na.indexOf(t) === 0 || t.indexOf(na) === 0)));
      };
      var usadas = {};
      var cols = P.actividades.map(function (a, i) {
        if (!incluida(i)) return null;
        var corto = a.corto || E.cortos[claveCorto(a)];
        if (corto) {
          var ex = cuaderno.filter(function (c) { return norm(c.titulo) === norm(corto); });
          if (ex.length === 1) { usadas[cuaderno.indexOf(ex[0])] = 1; return ex[0]; }
        }
        return null;
      });
      P.actividades.forEach(function (a, i) {
        if (cols[i] || !incluida(i)) return;
        var cand = cuaderno.filter(function (c, k) { return !usadas[k] && casa(norm(c.titulo), a); });
        var dudosa = cand.length !== 1 || P.actividades.some(function (b, j) { return j !== i && casa(norm(cand[0].titulo), b); });
        if (dudosa) {
          if (cand.length) log('⚠ «' + a.nombre + '»: la columna «' + cand.map(function (c) { return c.titulo; }).join('» / «') +
            '» podría ser de otra actividad; no pongo notas. Dale en Séneca una descripción corta distinta y vuelve a empezar.');
          cols[i] = null; cols[i + '_dudosa'] = !!cand.length;
          return;
        }
        usadas[cuaderno.indexOf(cand[0])] = 1; cols[i] = cand[0];
      });
      vivo = { t0: Date.now(), hechas: 0, total: 0, porAct: {}, ultima: '' };
      cols.forEach(function (ca, i) { if (ca) { vivo.total += ca.notActEvas.length; vivo.porAct[i] = [0, ca.notActEvas.length]; } });
      for (var i = 0; i < P.actividades.length; i++) {
        var a = P.actividades[i], ca = cols[i];
        if (!incluida(i)) continue; // no elegida para subir, o descartada al confirmar
        avanceNotas = i / P.actividades.length; pintar();
        if (!ca && cols[i + '_dudosa']) { tot.avisos++; continue; }
        if (!ca) {
          log('⚠ «' + a.nombre + '» no está en el cuaderno. Columnas vistas: ' +
            (cuaderno.map(function (c) { return '«' + c.titulo + '»'; }).join(', ') || 'ninguna') + '.');
          tot.avisos++;
          continue;
        }
        var r = { guardado: 0, igual: 0, sinNota: 0, deshabilitado: 0, noVerif: 0, sinAlumno: [], faltan: {} };
        for (var j = 0; j < ca.notActEvas.length; j++) {
          var x = ca.notActEvas[j];
          avanceNotas = (i + j / ca.notActEvas.length) / P.actividades.length;
          notaActual = { act: a.nombre, j: j + 1, n: ca.notActEvas.length }; pintar();
          if (j) { vivo.hechas++; vivo.porAct[i][0] = j; }
          var m = await pagina('leerModal', { xNotActEva: x });
          var k = porClave[claveNombre(m.alumno)];
          if (k == null) k = E.mapa[claveNombre(m.alumno)]; // emparejado a mano en el cotejo
          if (k == null) { r.sinAlumno.push(m.alumno); continue; }
          var notas = a.notas[k];
          if (!notas) { r.sinNota++; continue; }
          var g = await pagina('grabarNotas', { xNotActEva: x, notas: notas });
          vivo.ultima = { alumno: m.alumno, estado: g.estado, notas: Object.keys(notas).map(function (c) { return c + ' ' + notas[c]; }).join(' · ') };
          (g.faltan || []).forEach(function (c) { r.faltan[c] = 1; });
          if (g.estado === 'guardado') r.guardado++;
          else if (g.estado === 'igual') r.igual++;
          else if (g.estado === 'deshabilitado') r.deshabilitado++;
          else r.noVerif++;
        }
        vivo.hechas++; vivo.porAct[i][0] = ca.notActEvas.length;
        tot.guardadas += r.guardado; tot.iguales += r.igual;
        var faltan = Object.keys(r.faltan);
        tot.avisos += r.noVerif + r.sinAlumno.length + r.deshabilitado + (faltan.length ? 1 : 0);
        log('«' + a.nombre + '»: ' + r.guardado + ' guardadas, ' + r.igual + ' ya iguales' +
          (r.sinNota ? ', ' + r.sinNota + ' sin nota' : '') +
          (r.deshabilitado ? ', ' + r.deshabilitado + ' bloqueadas' : '') +
          (r.noVerif ? ', ⚠ ' + r.noVerif + ' sin verificar' : '') +
          (r.sinAlumno.length ? ', ⚠ sin emparejar: ' + r.sinAlumno.join('; ') : '') + '.');
        if (faltan.length) log('⚠ «' + a.nombre + '» en Séneca no tiene ' + faltan.join(', ') + ': añádelos a la actividad en Séneca y vuelve a empezar para poner esas notas.');
      }
      fase(null);
      pulsarRefrescar(); // que el cuaderno muestre las notas nuevas
      tot.creadas = Object.keys(E.progreso.acts).filter(function (k) { return E.progreso.acts[k] === 'creada'; }).length;
      tot.clase = P.clase; tot.grupo = E.grupo.desc; tot.fecha = Date.now();
      E.resultado = tot; verFin = true; notaActual = null; vivo = null;
      log('✓ Terminado.');
    } catch (e) {
      parar(e.message);
    }
    poniendo = false; guardar(); pintar();
  }

  // ---------- motor: avanza el recorrido según la pantalla ----------
  var PASOS = { irGrupos: 1, cargarGrupos: 1, eligeGrupo: 1, irAlumnos: 1, alumnos: 1, cotejo: 1, irParam: 2, cat: 2, catForm: 2, catTras: 2,
    irActs: 3, acts: 3, confirmar: 3, actForm: 3, actTras: 3, irNotas: 4, notas: 4 };
  /** Pulsa el botón «Refrescar» de la pantalla (la función de Séneca no siempre está cargada aún). */
  function pulsarRefrescar() {
    var b = [].filter.call(document.querySelectorAll('button, a, input[type="button"]'), function (x) {
      return norm(x.textContent || x.value) === 'refrescar';
    })[0];
    if (b) b.click();
  }
  /**
   * Actividades y Cuaderno no recargan su tabla hasta pulsar «Refrescar»: se
   * pulsa una vez por fase y se da un respiro antes de leerla. true = esperar.
   */
  function refrescarAntes(F) {
    if (!F.refrescado) { F.refrescado = Date.now(); guardar(); pulsarRefrescar(); return true; }
    return Date.now() - F.refrescado < 2500;
  }
  function empezar() {
    E.progreso = { acts: {} }; E.catReal = {}; E.catIdx = 0; E.resultado = null; grupoElegido = null; vivo = null;
    log('Empiezo.');
    // Clase ya volcada antes: se reutiliza su grupo (y el cotejo, si el alumnado no ha cambiado).
    E.grupo = grupoDeClase();
    if (E.grupo) {
      log('Grupo: «' + E.grupo.desc + '» (el de la última vez).');
      trasGrupo();
    } else {
      E.mapa = {};
      fase('irGrupos');
    }
    avanzar();
  }
  function trasGrupo() {
    if (E.cotejado === firmaCotejo()) { log('✓ Alumnado ya cotejado.'); return fase('irActs'); }
    E.mapa = {};
    fase('irAlumnos');
  }
  function avanzar() {
    var F = E.flujo, pt = pantalla(), P = E.paquete;
    if (!F || !P || F.parado || poniendo || apartada()) return;
    if (++F.intentos > 40) return parar('Séneca no responde como esperaba en este paso (fase «' + F.fase + '», pantalla «' +
      (pt || '?') + '»). Pulsa Reintentar o informa del fallo.');
    guardar();
    switch (F.fase) {
      case 'irGrupos':
        // Sin grupos cargados (horario nuevo o cambiado) la lista sale vacía: se cargan.
        if (pt === 'grupos') {
          if (leerGrupos().length) return fase('eligeGrupo');
          if (F.cargados) return F.intentos < 8 ? undefined : parar('Tras cargarlos, Séneca sigue sin mostrar grupos: seguramente falta tu horario. Revísalo y pulsa Reintentar.');
          return fase('cargarGrupos');
        }
        if (F.intentos === 1) irMenu('Mis alumnos y alumnas', 'Grupos de alumnos/as');
        return;
      case 'cargarGrupos':
        // Como los botones «Carga de grupos» y «Validar» de esa pantalla.
        if (!F.cargado) {
          F.cargado = true; guardar();
          log('No tienes grupos cargados: los cargo desde tu horario.');
          return llamar('cargar_grupos');
        }
        if (!leerGrupos().length) {
          if (F.intentos < 15) return;
          // Sin horario grabado, «Carga de grupos» no tiene nada que cargar.
          return parar('No hay grupos que cargar: seguramente aún no tienes el horario grabado en Séneca. ' +
            'Grábalo (o pide que te lo graben) y pulsa Reintentar.');
        }
        log('✓ Grupos cargados: los valido.');
        fase('irGrupos', { cargados: true });
        return llamar('aceptar');
      case 'eligeGrupo': case 'cotejo': case 'confirmar': F.intentos = 0; return; // espera al docente
      case 'irAlumnos':
        if (pt === 'alumnos') return fase('alumnos');
        if (F.intentos === 1) irMenu('Mis alumnos y alumnas', 'Mis alumnos y alumnas');
        return;
      case 'alumnos':
        var sa = campo('X_OFERTAMATRIG');
        if (!sa) return;
        var oa = opcionGrupo(sa, true);
        if (!oa) return parar('No encuentro el grupo «' + E.grupo.desc + '» en «Mis alumnos y alumnas» (opciones: ' + opcionesTexto(sa) + ').');
        if (sa.value !== oa.value) { sa.value = oa.value; return cambiar(sa); }
        var ns = leerAlumnos();
        // Espera a la lista del grupo (Séneca la recarga al cambiar el combo).
        if (!ns.length || (E.grupo.n && ns.length !== E.grupo.n && F.intentos < 8)) return;
        return cotejar(ns);
      case 'irParam':
        if (pt === 'parametros') return fase('cat', { verificar: F.verificar, abr: F.abr });
        if (F.intentos === 1) irMenu('Cuaderno de clase', 'Parámetros');
        return;
      case 'cat':
        // La tabla de categorías vive en su pestaña: si no está en pantalla, se abre.
        if (!$('[name^="OpEmergenteTB_CATACTEVA"]') && F.intentos < 6) {
          if (F.intentos === 1) {
            var tab = [].filter.call(document.querySelectorAll('a'), function (x) { return norm(x.textContent) === 'categoria'; })[0];
            if (tab) tab.click();
          }
          return;
        }
        var ya = categoriaExistente();
        if (ya) {
          var cc = catCur();
          E.catReal[cc.descripcion] = ya;
          if (F.verificar) log('✓ Categoría «' + ya + '» creada.'); else
          log('✓ Uso la categoría existente «' + ya + '»' + (ya === cc.descripcion ? '' : ' (equivale a «' + cc.descripcion + '»)') + '.');
          return fase('irActs', { sinCat: cc.descripcion }); // no volver aquí aunque el combo no la muestre
        }
        // Se acaba de guardar y no aparece: no se intenta crear otra vez (evita duplicados).
        if (F.verificar) return parar('He guardado la categoría «' + catCur().descripcion + '» (' + F.abr + '), pero no la encuentro ' +
          'en Parámetros del cuaderno. Revisa allí si está y pulsa Reintentar.');
        log('La categoría «' + catCur().descripcion + '» no existe en Séneca: la creo.');
        fase('catForm', { orden: ordenMaximo() }); return llamar('nuevo');
      case 'catForm':
        if (pt === 'formCategoria') return rellenarCategoria();
        if (F.intentos > 12) return parar('No se ha abierto el formulario de nueva categoría en Parámetros del cuaderno. ' +
          'Abre la pestaña «Categoría» de Parámetros y pulsa Reintentar.');
        return;
      case 'catTras':
        if (pt !== 'formCategoria') { log('✓ Categoría «' + catCur().descripcion + '» creada.'); return fase('irActs'); }
        // Tras guardar, Séneca puede dejar en pantalla un formulario nuevo, vacío: no es un
        // error. Se comprueba en la lista de Parámetros que la categoría ya está.
        if (campo('C_CATACTEVA').value !== F.abr) return fase('irParam', { verificar: true, abr: F.abr });
        // Sigue el mismo formulario relleno: Séneca no la ha aceptado.
        if (F.intentos > 8) {
          var er = errorSeneca();
          return parar('Séneca no ha guardado la categoría «' + catCur().descripcion + '» (abreviatura «' + F.abr + '»)' +
            (er ? ': «' + er + '»' : '') + '. Si ya tienes otra con esa abreviatura, cámbiala en iAsistente y vuelve a enviar, ' +
            'o créala tú en Séneca y pulsa Reintentar.');
        }
        return;
      case 'irActs':
        if (pt === 'actividades') return fase('acts', { sinCat: F.sinCat });
        if (F.intentos === 1) irMenu('Cuaderno de clase', 'Actividades');
        return;
      case 'acts':
        if (pt !== 'actividades' || asegurarFiltros() || refrescarAntes(F)) return;
        // La categoría se comprueba aquí (el combo lista todas); solo si falta se va a Parámetros.
        // Antes de crear nada, el docente confirma la lista: lo que parezca ya existir
        // (descripción recortada o cambiada a mano en Séneca) tiene que decidirlo él.
        if (!E.progreso.confirmado) {
          var filas = filasActividades(), tabla0 = textosTabla(), faltan = [];
          for (var k = 0; k < P.actividades.length; k++) {
            if (incluida(k) && !actividadExiste(k, tabla0, filas)) {
              var sim = parecidas(P.actividades[k], filas);
              faltan.push({ i: k, sim: sim, op: sim.length ? '' : 'crear' });
            }
          }
          guardar();
          if (faltan.length) return fase('confirmar', { faltan: faltan, filas: filas });
          E.progreso.confirmado = true; guardar();
        }
        // Cada actividad, con la categoría de su Unidad: si falta, se crea en Parámetros.
        var i = siguienteActividad();
        if (i < 0) { log('✓ Las actividades están en Séneca.'); return fase('irNotas'); }
        E.catIdx = i; guardar();
        var cc = catCur(), oc = categoriaEnCombo();
        if (oc) E.catReal[cc.descripcion] = oc.text.trim();
        else if (F.sinCat !== cc.descripcion) { log('Falta la categoría «' + cc.descripcion + '»: voy a crearla.'); return fase('irParam'); }
        if (!oc) return parar('Falta la categoría «' + cc.descripcion + '» en Séneca.');
        fase('actForm', { idx: i }); return llamar('nueva');
      case 'actForm':
        if (pt === 'formActividad') rellenarActividad();
        return;
      case 'actTras':
        // Séneca no deja dos actividades con la misma descripción corta en el grupo y evaluación.
        if (document.body && /ya existe una actividad evaluable/i.test(document.body.innerText)) {
          E.progreso.acts[F.idx] = 'existia';
          log('✓ «' + P.actividades[F.idx].nombre + '» ya existía en Séneca.');
          return fase('irActs');
        }
        if (pt === 'actividades') {
          E.progreso.acts[F.idx] = 'creada';
          log('✓ «' + P.actividades[F.idx].nombre + '» creada.');
          fase('acts');
        }
        return;
      case 'irNotas':
        if (pt === 'cuaderno') return fase('notas');
        if (F.intentos === 1) irMenu('Cuaderno de clase', 'Cuaderno');
        return;
      case 'notas':
        if (pt !== 'cuaderno' || asegurarFiltros() || refrescarAntes(F)) return;
        ponerNotas();
    }
  }

  // ---------- panel ----------
  // Dos vistas: en reposo, una tarjeta en la esquina (o su icono, minimizada);
  // en marcha, un diálogo centrado de alto fijo (cabecera, pasos y pie quietos;
  // solo el cuerpo hace scroll), con Séneca difuminada trabajando por detrás.
  var ICO = {
    flecha: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    papelera: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
    plegar: '<path d="M6 9l6 6 6-6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    alerta: '<path d="M12 8v5M12 16.5v.5"/><circle cx="12" cy="12" r="9"/>',
    reintentar: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
    registro: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
    persona: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/>',
    bombilla: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    correo: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    reloj: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
  };
  function ico(n) { return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true">' + ICO[n] + '</svg>'; }
  var LOGO = chrome.runtime.getURL('icons/128.png');

  var host = document.createElement('div'), raiz = host.attachShadow({ mode: 'open' });
  raiz.innerHTML = '<style>' + [
    ':host{all:initial;--tinta:#0f172a;--suave:#64748b;--linea:#e6e8ef;--fondo:#fff;--niebla:#f5f6fa;--marca:#007932;' +
      '--verde:#27ae60;--verde-s:#e8f6ee;--azul:#4f6ef7;--ambar:#b7791f;--ambar-s:#fdf4e3;--rojo:#d8434a;--rojo-s:#fdecec;' +
      '--sombra:0 1px 2px rgba(15,23,42,.06),0 8px 24px rgba(15,23,42,.12),0 24px 60px rgba(15,23,42,.10)}',
    '*{box-sizing:border-box;font-family:"Open Sans",ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}',
    'button{font:inherit;cursor:pointer}',
    '.i{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}',
    // Icono minimizado
    '.fab{position:relative;width:56px;height:56px;padding:0;border:0;border-radius:16px;background:none;box-shadow:var(--sombra);' +
      'transition:transform .2s cubic-bezier(.2,.8,.2,1);animation:entra .35s cubic-bezier(.2,.8,.2,1)}',
    '.fab:hover{transform:translateY(-2px) scale(1.04)}.fab:active{transform:scale(.96)}',
    '.fab img{width:100%;height:100%;border-radius:16px;display:block}',
    '.fab .punto{position:absolute;top:-4px;right:-4px;width:14px;height:14px;border-radius:50%;background:var(--verde);border:2.5px solid #fff}',
    '.fab .punto.vivo{background:#f08c00;animation:late 1.6s ease-in-out infinite}',
    // Tarjeta y diálogo
    '.card,.dlg{background:var(--fondo);color:var(--tinta);border-radius:20px;box-shadow:var(--sombra);font-size:14px;line-height:1.45;' +
      'display:flex;flex-direction:column;overflow:hidden;animation:entra .32s cubic-bezier(.2,.8,.2,1)}',
    '.card{width:360px;max-height:min(560px,calc(100vh - 32px))}',
    '.dlg{width:min(720px,calc(100vw - 32px));height:min(640px,calc(100vh - 48px))}',
    '.hd{display:flex;align-items:center;gap:12px;padding:16px 16px 12px 18px}',
    '.logo{width:34px;height:34px;border-radius:10px;flex:none}',
    '.tt{flex:1;min-width:0}.tt b{display:block;font-size:15px;letter-spacing:-.01em}.tt span{display:block;color:var(--suave);font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.ib{width:34px;height:34px;border:0;border-radius:10px;background:transparent;color:var(--suave);display:grid;place-items:center;transition:background .15s}',
    '.ib:hover{background:var(--niebla);color:var(--tinta)}',
    '.bd{flex:1;min-height:0;overflow:auto;padding:4px 18px 16px;overscroll-behavior:contain}',
    '.ft{display:flex;align-items:center;gap:10px;padding:14px 16px;border-top:1px solid var(--linea);background:#fbfbfd}',
    '.ft .sp{flex:1}',
    // Botones
    '.btn{display:inline-flex;align-items:center;gap:8px;height:40px;padding:0 16px;border-radius:12px;border:1px solid transparent;font-weight:600;font-size:14px;' +
      'transition:transform .12s,background .15s,box-shadow .15s,opacity .15s}',
    '.btn:active{transform:scale(.97)}.btn:disabled{opacity:.45;cursor:default;transform:none}',
    '.pri{background:var(--marca);color:#fff;box-shadow:0 1px 0 rgba(255,255,255,.12) inset,0 4px 14px rgba(0,121,50,.28)}',
    '.pri:hover:not(:disabled){background:#00652a}.pri .i{transition:transform .2s}.pri:hover:not(:disabled) .i{transform:translateX(3px)}',
    '.sec{background:var(--fondo);color:var(--tinta);border-color:var(--linea)}.sec:hover{background:var(--niebla)}',
    '.fant{background:transparent;color:var(--suave);padding:0 10px}.fant:hover{background:var(--niebla);color:var(--tinta)}',
    '.peligro{background:var(--rojo-s);color:var(--rojo)}.peligro:hover{background:#fbdcdd}',
    'button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid var(--azul);outline-offset:2px}',
    // Contenido de la tarjeta
    '.eti{font-size:11.5px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--suave);margin:4px 0 6px}',
    '.clase{font-size:17px;font-weight:650;letter-spacing:-.015em;margin:0 0 12px;line-height:1.3}',
    '.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}',
    '.chip{display:inline-flex;gap:5px;align-items:baseline;background:var(--niebla);border-radius:999px;padding:5px 11px;font-size:12.5px;color:var(--suave)}',
    '.chip b{color:var(--tinta);font-weight:600}',
    '.grp{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--suave);padding:10px 12px;border:1px dashed var(--linea);border-radius:12px}',
    '.grp b{color:var(--tinta)}.lnk{margin-left:auto;border:0;background:none;color:var(--azul);font-weight:600;font-size:13px;padding:2px 4px;border-radius:6px}',
    '.lnk:hover{text-decoration:underline}',
    '.inf{display:inline-flex;align-items:center;gap:6px;margin:8px 0 0 -4px;font-size:12.5px}.inf .i{width:15px;height:15px}',
    '.res{display:flex;gap:10px;align-items:center;background:var(--verde-s);color:#0d6e4e;border-radius:14px;padding:10px 12px;margin:2px 0 14px;font-size:13px}',
    '.res .i{color:var(--verde)}.res.av{background:var(--ambar-s);color:#8a5a12}.res.av .i{color:var(--ambar)}',
    // Pasos y progreso
    '.pasos{display:flex;gap:0;padding:0 18px;margin:2px 0 12px;list-style:none}',
    '.pasos li{flex:1;display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--suave);white-space:nowrap}',
    '.pasos li:not(:last-child)::after{content:"";flex:1;height:2px;margin:0 8px;border-radius:2px;background:var(--linea)}',
    '.pasos li.hecho:not(:last-child)::after{background:var(--verde)}',
    '.pasos .n{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;font-size:12px;font-weight:700;background:var(--niebla);color:var(--suave);flex:none}',
    '.pasos .hecho .n{background:var(--verde);color:#fff}.pasos .hecho .n .i{width:14px;height:14px;stroke-width:3}',
    '.pasos .ahora{color:var(--tinta);font-weight:600}.pasos .ahora .n{background:var(--marca);color:#fff;box-shadow:0 0 0 4px rgba(79,110,247,.18)}',
    '.barra{height:4px;background:var(--niebla);margin:0 18px 6px;border-radius:4px;overflow:hidden}',
    '.barra i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#3ecf9a,#4f6ef7);transition:width .6s cubic-bezier(.2,.8,.2,1)}',
    // Vista «trabajando»
    '.trab{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:14px;padding:24px 8px}',
    '.anillo{width:56px;height:56px;border-radius:50%;border:4px solid var(--niebla);border-top-color:var(--azul);animation:gira .9s linear infinite}',
    '.trab h3{margin:0;font-size:18px;letter-spacing:-.015em}.trab p{margin:0;color:var(--suave);font-size:13.5px;max-width:380px}',
    '.fin .ok{width:64px;height:64px;border-radius:50%;background:var(--verde-s);color:var(--verde);display:grid;place-items:center;animation:pop .5s cubic-bezier(.2,1.4,.4,1)}',
    '.fin .ok .i{width:32px;height:32px;stroke-width:2.5}',
    '.cifras{display:flex;gap:10px;margin-top:6px}.cifra{min-width:108px;padding:12px 14px;border-radius:14px;background:var(--niebla)}',
    '.cifra b{display:block;font-size:24px;letter-spacing:-.02em}.cifra span{font-size:12px;color:var(--suave)}',
    '.cifra.av b{color:var(--ambar)}',
    // Vista «trabajando»: qué hace, cifras, actividades, última nota y consejo
    '.queh{display:flex;align-items:center;gap:16px;padding:8px 0 16px}.queh .anillo{width:44px;height:44px;flex:none}',
    '.queh h3{margin:0 0 2px;font-size:17px;letter-spacing:-.015em}.queh p{margin:0;color:var(--suave);font-size:13px}',
    '.cifras.mini{margin:0 0 14px}.cifras.mini .cifra{flex:1;min-width:0;padding:10px 12px}',
    '.cifras.mini b{font-size:20px;font-variant-numeric:tabular-nums}.cifras.mini b small{font-size:13px;color:var(--suave);font-weight:600}',
    '.acts{list-style:none;margin:0;padding:0;border:1px solid var(--linea);border-radius:14px;overflow:hidden}',
    '.acts li{position:relative;display:flex;align-items:center;gap:10px;padding:9px 12px;font-size:13px}',
    '.acts li+li{border-top:1px solid var(--linea)}',
    '.acts .pt{width:8px;height:8px;border-radius:50%;background:var(--linea);flex:none;transition:background .3s}',
    '.acts .ok .pt{background:var(--verde)}.acts .va .pt{background:var(--azul);animation:lateAz 1.6s ease-in-out infinite}',
    '.acts .nm{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.acts .es{color:var(--suave);font-size:12px;font-variant-numeric:tabular-nums}.acts .ok .es{color:#0d6e4e}.acts .va .es{color:var(--azul);font-weight:600}',
    '.acts .mb{position:absolute;left:0;right:0;bottom:0;height:2px}.acts .mb i{display:block;height:100%;background:var(--verde);transition:width .4s}',
    '.acts .va .mb i{background:var(--azul)}',
    '.ult{display:flex;gap:8px;align-items:flex-start;margin:12px 0 0;font-size:12.5px;color:var(--suave)}.ult .i{width:16px;height:16px;color:var(--verde);margin-top:1px}',
    '.ult b{color:var(--tinta);font-weight:600}',
    '.consejo{display:flex;gap:8px;align-items:flex-start;margin:14px 0 0;padding:10px 12px;border-radius:12px;background:#f5f7ff;color:#3b4a8a;font-size:12.5px}',
    '.consejo .i{width:16px;height:16px;color:var(--azul);margin-top:1px}',
    '.ahorro{display:flex;align-items:center;gap:8px;margin:4px 0 0;font-size:13px;color:var(--suave)}.ahorro .i{color:var(--verde)}.ahorro b{color:var(--tinta)}',
    // Elegir grupo
    '.tit{font-size:18px;font-weight:650;letter-spacing:-.015em;margin:6px 0 4px}.sub{color:var(--suave);font-size:13.5px;margin:0 0 14px}',
    '.grupos{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}',
    '.gc{position:relative;display:block;border:1.5px solid var(--linea);border-radius:14px;padding:12px 14px;cursor:pointer;transition:border-color .15s,box-shadow .15s,background .15s}',
    '.gc:hover{border-color:#c9cee0}.gc input{position:absolute;opacity:0;pointer-events:none}',
    '.gc.sel{border-color:var(--azul);background:#f5f7ff;box-shadow:0 0 0 3px rgba(79,110,247,.15)}',
    '.gc b{display:block;font-size:14.5px;margin-bottom:3px;padding-right:56px}.gc small{display:block;color:var(--suave);font-size:12px;line-height:1.35}',
    '.gc .n{position:absolute;top:10px;right:10px;font-size:11.5px;font-weight:600;padding:2px 8px;border-radius:999px;background:var(--verde-s);color:#0d6e4e}',
    '.gc .n.dif{background:var(--ambar-s);color:#8a5a12}',
    '.gc .n{display:inline-flex;align-items:center;gap:3px}.gc .n .i{width:12px;height:12px;stroke-width:2.4}',
    '.pasos .error .n{background:var(--rojo);box-shadow:0 0 0 4px rgba(216,67,74,.18)}',
    '.cnt{font-size:11px;background:var(--niebla);border-radius:999px;padding:0 7px;color:var(--suave)}',
    '.gc .sug{display:inline-block;margin-top:6px;font-size:11px;font-weight:600;color:var(--azul)}',
    // Cotejo
    '.par{width:100%;border-collapse:collapse}.par td{padding:8px 4px;border-bottom:1px solid var(--linea);font-size:13.5px}',
    '.par select{width:100%;height:36px;border:1px solid var(--linea);border-radius:10px;padding:0 8px;font:inherit;background:#fff}',
    '.nota{font-size:12.5px;color:var(--suave);margin-top:10px}',
    '.par small.dif{color:#8a5a12}',
    // Pestañas Notas / Observaciones
    '.tabs{display:flex;gap:4px;margin:0 16px 6px;padding:4px;background:var(--niebla);border-radius:12px}',
    '.tab{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;border:0;background:transparent;border-radius:9px;padding:7px 8px;font-weight:600;font-size:13px;color:var(--suave)}',
    '.tab:hover{color:var(--tinta)}.tab.on{background:#fff;color:var(--marca);box-shadow:0 1px 2px rgba(15,23,42,.1)}',
    '.tab .cnt{background:var(--verde-s);color:var(--marca)}.tab .cnt.v{background:var(--linea);color:var(--suave)}',
    '.vacio{color:var(--suave);font-size:13px;background:var(--niebla);border-radius:12px;padding:12px 14px;margin:4px 0}',
    '.seli small{color:var(--suave)}',
    // Qué subir
    '.selg{margin:6px 0 0 4px}.selc,.seli{display:flex;align-items:center;gap:8px;font-size:13px;padding:3px 0;cursor:pointer}.seli{padding-left:22px;color:#334155}',
    '.selc input,.seli input{width:16px;height:16px;accent-color:#27ae60;flex:none}',
    // Error
    '.err{display:flex;gap:12px;background:var(--rojo-s);color:#9b2c31;border-radius:14px;padding:14px;margin-top:8px}.err .i{color:var(--rojo);margin-top:1px}',
    // Registro
    '.reg{margin-top:14px}.reg summary{display:inline-flex;align-items:center;gap:6px;cursor:pointer;color:var(--suave);font-size:12.5px;font-weight:600;list-style:none;padding:4px 6px;border-radius:8px}',
    '.reg summary::-webkit-details-marker{display:none}.reg summary:hover{color:var(--tinta);background:var(--niebla)}.reg summary .i{width:15px;height:15px}',
    '.log{margin-top:8px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;line-height:1.55;white-space:pre-wrap;max-height:170px;overflow:auto;' +
      'background:var(--niebla);border-radius:12px;padding:10px 12px;color:#334155}',
    '@keyframes entra{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}',
    '@keyframes gira{to{transform:rotate(360deg)}}',
    '@keyframes pop{from{transform:scale(.4);opacity:0}to{transform:none;opacity:1}}',
    '@keyframes late{50%{box-shadow:0 0 0 6px rgba(240,140,0,.25)}}',
    '@keyframes lateAz{50%{box-shadow:0 0 0 5px rgba(79,110,247,.22)}}',
    '@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}'
  ].join('') + '</style><div id="c"></div>';
  document.documentElement.appendChild(host);
  var C = raiz.getElementById('c');

  function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  var grupoElegido = null;   // índice marcado en la lista de grupos (antes de «Continuar»)
  var verFin = false;        // mostrar la pantalla de resultado al terminar
  var regAbierto = false;    // registro desplegado
  var confirmarDescarte = 0; // marca de tiempo del primer clic en «Descartar datos»

  // Solo se redibuja si cambia el contenido (Séneca muta el DOM a menudo: redibujar
  // siempre reiniciaba el scroll y cerraba los desplegables). La barra de progreso
  // se anima desde su valor anterior.
  var ultimoHtml = '', ultimoAvance = 0;
  var ESTILO = {
    oculto: 'display:none',
    esquina: 'position:fixed;right:20px;bottom:20px;z-index:2147483647',
    centro: 'position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;background:rgba(15,23,42,.28);' +
      'backdrop-filter:blur(6px) saturate(.9);-webkit-backdrop-filter:blur(6px) saturate(.9)'
  };
  /**
   * Lleva el nodo v a ser como n tocando solo lo que difiere (atributos, textos,
   * hijos). Rehacer el diálogo entero repetía su animación de entrada y
   * reiniciaba giros y barras: eso era el parpadeo. Los data-fijo se dejan
   * como están (los anima el propio script) mientras sigan en la vista.
   */
  function parchear(v, n) {
    if (v.nodeType !== n.nodeType || v.nodeName !== n.nodeName) return v.parentNode.replaceChild(n.cloneNode(true), v);
    if (v.nodeType === 3) { if (v.nodeValue !== n.nodeValue) v.nodeValue = n.nodeValue; return; }
    if (v.nodeType !== 1) return;
    if (v.hasAttribute('data-fijo')) {
      // Se conserva si sigue siendo el mismo elemento; si en su sitio va otro (el
      // giro que pasa a ser el check final), se cambia.
      if (!n.hasAttribute('data-fijo')) v.parentNode.replaceChild(n.cloneNode(true), v);
      return;
    }
    [].slice.call(n.attributes).forEach(function (at) { if (v.getAttribute(at.name) !== at.value) v.setAttribute(at.name, at.value); });
    [].slice.call(v.attributes).forEach(function (at) { if (!n.hasAttribute(at.name)) v.removeAttribute(at.name); });
    var vc = v.childNodes, nc = n.childNodes;
    for (var k = 0; k < nc.length; k++) { if (vc[k]) parchear(vc[k], nc[k]); else v.appendChild(nc[k].cloneNode(true)); }
    while (vc.length > nc.length) v.removeChild(v.lastChild);
  }
  function poner(html, modo, avancePct) {
    host.style.cssText = ESTILO[modo];
    if (html === ultimoHtml) return;
    ultimoHtml = html;
    var tpl = document.createElement('template'); tpl.innerHTML = html;
    var nuevo = tpl.content.firstElementChild, viejo = C.firstElementChild;
    if (viejo && nuevo && viejo.className === nuevo.className) parchear(viejo, nuevo); // misma vista
    else C.innerHTML = html;
    var lg = C.querySelector('.log'); if (lg) lg.scrollTop = lg.scrollHeight; // el registro, siempre en lo último
    // El giro arranca en su fase aunque el nodo sea nuevo.
    var an = C.querySelector('.anillo'); if (an && !an.style.animationDelay) an.style.animationDelay = '-' + Math.round(performance.now() % 900) + 'ms';
    var barra = C.querySelector('.barra i');
    if (barra && avancePct != null && barra.style.width !== avancePct + '%') {
      barra.style.width = ultimoAvance + '%';
      barra.getBoundingClientRect(); // fuerza el estilo inicial para que la transición se vea
      barra.style.width = avancePct + '%';
      ultimoAvance = avancePct;
    }
  }
  /** Avance total del recorrido (0–1): grupo 10 %, categoría 10 %, actividades 40 %, notas 40 %. */
  function avance(paso) {
    var n = E.paquete.actividades.length || 1;
    if (paso <= 1) return 0.05;
    if (paso === 2) return 0.15;
    if (paso === 3) return 0.2 + 0.4 * Object.keys(E.progreso.acts).length / n;
    return 0.6 + 0.4 * avanceNotas;
  }
  /** Qué está haciendo ahora, en palabras del docente. */
  function queHace(F) {
    var P = E.paquete, cat = '«' + catNombre(catCur()) + '»';
    switch (F.fase) {
      case 'irGrupos': return ['Abriendo tus grupos', 'Leo en Séneca los grupos de alumnado que tienes.'];
      case 'cargarGrupos': return ['Cargando tus grupos', 'No tenías grupos cargados (pasa al grabar o cambiar el horario). Los cargo y valido por ti, como el botón «Carga de grupos».'];
      case 'irAlumnos': case 'alumnos': return ['Comparando el alumnado', 'Compruebo que el alumnado de «' + E.grupo.desc + '» es el mismo que en iAsistente.'];
      case 'irParam': case 'cat': case 'catForm': case 'catTras': return ['Preparando la categoría', 'Creo la categoría ' + cat + ' en tu cuaderno de Séneca.'];
      case 'irActs': case 'acts': return ['Revisando las actividades', 'Miro qué actividades evaluables existen ya en Séneca.'];
      case 'actForm': case 'actTras': return ['Creando «' + P.actividades[F.idx].nombre + '»', 'Relleno la actividad con su categoría, fecha, competencias y criterios.'];
      case 'irNotas': return ['Abriendo el cuaderno', 'Voy al cuaderno de clase para poner las notas.'];
      default:
        return notaActual
          ? ['Poniendo notas · ' + notaActual.j + ' de ' + notaActual.n, '«' + notaActual.act + '»: guardo cada nota y la vuelvo a leer para comprobarla.']
          : ['Preparando el cuaderno', 'Refresco la tabla de notas de Séneca.'];
    }
  }
  var selAbierta = false; // lista «Qué subir» desplegada
  /** Pestaña «Observaciones»: datos de observaciones.js (mismo mundo aislado), o null. */
  function obsVista() { return window.__iasObs ? window.__iasObs.vista() : null; }
  function obsAccion(a, arg) { if (window.__iasObs) window.__iasObs.accion(a, arg); }
  /** Pestaña visible: la elegida, salvo que esté vacía y la otra no. */
  function modoActual(P, V) {
    if (V && V.enMarcha) return 'observaciones';
    if (E.modo === 'observaciones') return V || !P ? 'observaciones' : 'notas';
    return P || !V ? 'notas' : 'observaciones';
  }
  function tabsHtml(modo, P, V) {
    var tab = function (t, txt, n, hay) {
      return '<button class="tab' + (modo === t ? ' on' : '') + '" data-a="tab" data-t="' + t + '" role="tab" aria-selected="' + (modo === t) + '">' +
        txt + '<span class="cnt' + (hay ? '' : ' v') + '">' + (hay ? n : '—') + '</span></button>';
    };
    return '<div class="tabs" role="tablist">' + tab('notas', 'Notas', P ? P.actividades.length : 0, !!P) +
      tab('observaciones', 'Observaciones', V ? V.n : 0, !!V) + '</div>';
  }
  /** Cuerpo y pie de la pestaña «Observaciones». */
  function obsHtml(V) {
    if (!V) return { cuerpo: '<p class="vacio">Sin observaciones enviadas. En iAsistente: Evaluación → Resumen del grupo → «📤 Enviar observaciones del grupo».</p>', pie: '' };
    var estado = V.parado ? '<div class="err">' + ico('alerta') + '<span>' + esc(V.parado) + '</span></div>'
      : V.enMarcha ? '<div class="res">' + ico('reloj') + '<span>Trabajando en <b>' + esc(V.actual) + '</b>… no uses esta pestaña de Séneca.</span></div>'
      : !V.enPantalla ? '<p class="vacio">Para empezar, en Séneca: Alumnado → Mis alumnos y alumnas → grupo → ⋮ del primer alumno → <b>Mis observaciones</b>.</p>'
      : '<p class="vacio">Listo: empiezo en <b>' + esc(V.actual) + '</b> y sigo hasta el último. Se guardan marcadas «Compartir».</p>';
    var todos = V.alumnos.every(function (x) { return x.sel; });
    var lista = V.enMarcha ? '' : '<details class="reg selw"' + (selAbierta ? ' open' : '') + '><summary>' + ico('persona') + 'Qué subir <span class="cnt">' + V.n + '/' + V.alumnos.length + '</span></summary>' +
      '<div class="selg"><label class="selc"><input type="checkbox" data-a="obsTodos"' + (todos ? ' checked' : '') + '><b>Todo el alumnado</b></label>' +
      V.alumnos.map(function (x) {
        return '<label class="seli"><input type="checkbox" data-a="obsSel" data-k="' + esc(x.clave) + '"' + (x.sel ? ' checked' : '') + '>' + esc(x.nombre) +
          (x.hecho ? ' <small>· ' + esc(x.hecho) + '</small>' : '') + '</label>';
      }).join('') + '</div></details>';
    var reg = V.log.length ? '<details class="reg"' + (regAbierto ? ' open' : '') + '><summary>' + ico('registro') + 'Registro <span class="cnt">' + V.log.length + '</span></summary>' +
      '<div class="log">' + esc(V.log.join('\n')) + '</div></details>' : '';
    var cuerpo = '<p class="eti">Desde iAsistente</p><h3 class="clase">' + esc(V.clase || '') + '</h3>' +
      '<div class="chips">' + (V.evaluacion ? '<span class="chip"><b>' + esc(V.evaluacion) + '</b></span>' : '') +
      '<span class="chip"><b>' + V.n + '</b> de ' + V.alumnos.length + ' a subir</span><span class="chip"><b>' + V.hechas + '</b> hechas</span></div>' +
      estado + lista + reg;
    var pie = V.parado ? '<button class="btn sec" data-a="obsCancelar">Cancelar</button><span class="sp"></span><button class="btn pri" data-a="obsReintentar">' + ico('reintentar') + 'Reintentar</button>'
      : V.enMarcha ? '<span class="sp"></span><button class="btn sec" data-a="obsCancelar">Parar</button>'
      : '<button class="btn fant" data-a="obsDescartar">' + ico('papelera') + 'Descartar</button><span class="sp"></span>' +
        '<button class="btn pri" data-a="obsEmpezar"' + (V.enPantalla && V.n ? '' : ' disabled') + '>Empezar' + ico('flecha') + '</button>';
    return { cuerpo: cuerpo, pie: pie };
  }
  /** En reposo: casillas por Unidad (categoría) y por actividad para elegir qué subir. */
  function seleccionHtml() {
    var P = E.paquete, n = P.actividades.filter(function (a, i) { return E.sel[i] !== false; }).length;
    return '<details class="reg selw"' + (selAbierta ? ' open' : '') + '><summary>' + ico('registro') + 'Qué subir <span class="cnt">' + n + '/' + P.actividades.length + '</span></summary>' +
      gruposCat().map(function (g, gi) {
        var todas = g.ids.every(function (i) { return E.sel[i] !== false; });
        return '<div class="selg"><label class="selc"><input type="checkbox" data-a="selGrupo" data-g="' + gi + '"' + (todas ? ' checked' : '') + '><b>' + esc(g.c) + '</b></label>' +
          g.ids.map(function (i) {
            return '<label class="seli"><input type="checkbox" data-a="selAct" data-i="' + i + '"' + (E.sel[i] !== false ? ' checked' : '') + '>' + esc(P.actividades[i].nombre) + '</label>';
          }).join('') + '</div>';
      }).join('') + '</details>';
  }
  function registroHtml() {
    if (!E.log.length) return '';
    return '<details class="reg"' + (regAbierto ? ' open' : '') + '><summary>' + ico('registro') + 'Registro <span class="cnt">' + E.log.length + '</span></summary>' +
      '<div class="log">' + esc(E.log.slice(-40).join('\n')) + '</div>' +
      '<button class="lnk inf" data-a="informe">' + ico('correo') + 'Enviar el registro para revisar un fallo</button></details>';
  }
  function cabecera(sub) {
    return '<header class="hd"><img class="logo" alt="" src="' + LOGO + '"><div class="tt"><b>iAsistente → Séneca</b>' +
      '<span>' + esc(sub) + '</span></div><button class="ib" data-a="cerrar" aria-label="Minimizar" title="Minimizar">' + ico('plegar') + '</button></header>';
  }
  function pasosHtml(paso, parado) {
    return '<ol class="pasos">' + ['Grupo', 'Categoría', 'Actividades', 'Notas'].map(function (t, k) {
      var n = k + 1, cl = n < paso ? 'hecho' : n === paso ? (parado ? 'ahora error' : 'ahora') : '';
      return '<li class="' + cl + '"><span class="n">' + (n < paso ? ico('check') : n === paso && parado ? '!' : n) + '</span>' + t + '</li>';
    }).join('') + '</ol>';
  }
  function hace(t) {
    var m = Math.round((Date.now() - t) / 60000);
    return m < 1 ? 'ahora mismo' : m < 60 ? 'hace ' + m + ' min' : m < 1440 ? 'hace ' + Math.round(m / 60) + ' h' : new Date(t).toLocaleDateString();
  }
  function resultadoHtml(r) {
    if (!r) return '';
    return '<div class="res' + (r.avisos ? ' av' : '') + '">' + ico(r.avisos ? 'alerta' : 'check') + '<span><b>Último volcado</b>' +
      (r.clase ? ' · ' + esc(r.clase) + ' → ' + esc(r.grupo) + ' · ' + hace(r.fecha) : '') + '<br>' + r.guardadas + ' notas guardadas, ' + r.iguales + ' ya estaban' + (r.avisos ? ', ' + r.avisos + ' con aviso (mira el registro)' : '') + '.</span></div>';
  }

  /**
   * Abre un correo de Gmail (todo el profesorado usa cuenta Google educativa)
   * con el registro y el contexto del fallo, para que lo revise el autor. El
   * docente lo ve antes de enviarlo.
   */
  var SOPORTE = 'frostov381@g.educaand.es'; // autor: recibe los informes de fallo
  function informar() {
    var P = E.paquete || {}, F = E.flujo || {};
    var cuerpo = ['Hola, la extensión iAsistente → Séneca ha fallado.', '', 'Qué estaba haciendo (opcional): ', '',
      '— Datos técnicos —', 'Versión: ' + chrome.runtime.getManifest().version, 'Fase: ' + (F.fase || '—') + (F.parado ? ' · Error: ' + F.parado : ''),
      'Pantalla: ' + pantalla(), 'Clase: ' + (P.clase || '—') + ' · ' + (P.evaluacion || '—') + ' · ' + ((P.actividades || []).length) + ' actividades',
      'Navegador: ' + navigator.userAgent, '', '— Registro —'].join('\n');
    // Las URL largas fallan: del registro se mandan las últimas líneas que quepan.
    var lineas = E.log.slice(-40);
    while (lineas.length > 5 && encodeURIComponent(cuerpo + lineas.join('\n')).length > 6000) lineas.shift();
    window.open('https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(SOPORTE) +
      '&su=' + encodeURIComponent('Fallo en iAsistente → Séneca ' + chrome.runtime.getManifest().version) +
      '&body=' + encodeURIComponent(cuerpo + '\n' + lineas.join('\n')), '_blank', 'noopener');
  }
  var CONSEJOS = [
    'Puedes cambiar de pestaña o de escritorio: sigo trabajando por detrás.',
    'Cada nota se guarda y se vuelve a leer de Séneca para comprobar que ha quedado bien.',
    'Si vuelves a enviar desde iAsistente, solo cambio lo que sea distinto: lo demás queda igual.',
    '«Mostrar» enseña la actividad a las familias en iPASEN; «Publicar nota», también su nota.',
    'No uses Séneca en esta pestaña mientras trabajo: podría perder el sitio. Otra pestaña, sin problema.',
    'Si algo falla, pulsa Reintentar: vuelvo sola a la pantalla que tocaba.'
  ];
  /** Minutos a mano que se ahorran (estimación: ~3 min por actividad creada, ~20 s por alumno/a calificado). */
  function ahorro(r) { return Math.round((r.creadas || 0) * 3 + r.guardadas / 3); }
  /** Lo que queda, por el ritmo de las notas ya puestas. */
  function quedaTexto() {
    if (!vivo || vivo.hechas < 3) return '…';
    var min = (Date.now() - vivo.t0) / vivo.hechas * (vivo.total - vivo.hechas) / 60000;
    return min < 1 ? '< 1 min' : '~' + Math.round(min) + ' min';
  }
  /** Cifras en vivo, estado de cada actividad y última nota comprobada. */
  function vivoHtml(F) {
    var P = E.paquete, n = P.actividades.length, paso = PASOS[F.fase];
    var listas = Object.keys(E.progreso.acts).length;
    var cifras = '<div class="cifras mini"><div class="cifra"><b>' + Math.min(listas, n) + '<small>/' + n + '</small></b><span>actividades</span></div>' +
      '<div class="cifra"><b>' + (vivo ? vivo.hechas + '<small>/' + vivo.total + '</small>' : '—') + '</b><span>alumnos/as calificados</span></div>' +
      '<div class="cifra"><b>' + (paso === 4 ? quedaTexto() : '—') + '</b><span>queda</span></div></div>';
    var lista = '<ul class="acts">' + P.actividades.map(function (a, i) {
      var st = E.progreso.acts[i], pa = vivo && vivo.porAct[i], cl, txt;
      if (pa && pa[0] >= pa[1]) { cl = 'ok'; txt = 'notas puestas'; }
      else if (pa && notaActual && notaActual.act === a.nombre) { cl = 'va'; txt = pa[0] + ' de ' + pa[1]; }
      else if ((F.fase === 'actForm' || F.fase === 'actTras') && F.idx === i) { cl = 'va'; txt = 'creando…'; }
      else if (st) { cl = 'ok'; txt = st === 'creada' ? 'creada' : 'ya estaba'; }
      else { cl = ''; txt = 'pendiente'; }
      return '<li class="' + cl + '"><span class="pt"></span><span class="nm">' + esc(a.nombre) + '</span><span class="es">' + txt + '</span>' +
        (pa ? '<span class="mb"><i style="width:' + Math.round(100 * pa[0] / (pa[1] || 1)) + '%"></i></span>' : '') + '</li>';
    }).join('') + '</ul>';
    var u = vivo && vivo.ultima;
    var ult = u ? '<p class="ult">' + ico(u.estado === 'guardado' || u.estado === 'igual' ? 'check' : 'alerta') + '<span><b>' + esc(u.alumno) + '</b> · ' +
      esc(u.notas) + ' — ' + ({ guardado: 'guardada y comprobada', igual: 'ya estaba así', deshabilitado: 'bloqueada en Séneca' }[u.estado] || 'sin verificar') + '</span></p>' : '';
    return cifras + lista + ult;
  }

  function pintar() {
    var P = E.paquete, F = E.flujo;
    if (apartada()) {
      return poner(avisoVisto ? '' : '<div class="card" role="alertdialog" aria-label="Copia duplicada"><div class="bd"><p class="tit">Tienes dos copias de la extensión</p>' +
        '<p class="sub">Ya está instalada la versión oficial de la Chrome Web Store, que se actualiza sola. Esta copia instalada a mano se queda quieta: ' +
        'quítala en <b>chrome://extensions</b> (botón «Quitar» de la que pone «Extensión descomprimida»).</p></div>' +
        '<footer class="ft"><span class="sp"></span><button class="btn pri" data-a="avisoOk">Entendido</button></footer></div>', avisoVisto ? 'oculto' : 'esquina');
    }
    var V = obsVista(), vivoObs = !!(V && V.enMarcha && !V.parado);
    if (!P && !V) return poner('', 'oculto'); // sin datos de iAsistente, la extensión no se ve
    if (!E.abierto) {
      return poner('<button class="fab" data-a="abrir" aria-label="Abrir iAsistente → Séneca" title="iAsistente → Séneca' +
        (F || vivoObs ? ' (trabajando…)' : '') + '"><img data-a="abrir" alt="" src="' + LOGO + '"><span data-a="abrir" class="punto' +
        (F || vivoObs ? ' vivo' : '') + '"></span></button>', 'esquina');
    }
    // ---- Pestañas en reposo (y observaciones en marcha, que no usa el diálogo grande) ----
    var modo = modoActual(P, V);
    if (!F && !verFin && (modo === 'observaciones' || !P)) {
      var o = modo === 'observaciones' ? obsHtml(V)
        : { cuerpo: '<p class="vacio">Sin notas enviadas. En iAsistente: Evaluación → Resumen del grupo → «📤 Enviar notas a Séneca».</p>', pie: '' };
      return poner('<div class="card" role="dialog" aria-label="iAsistente → Séneca">' + cabecera(modo === 'observaciones' ? 'Observaciones compartidas' : 'Notas y actividades') +
        (V && V.enMarcha ? '' : tabsHtml(modo, P, V)) + '<div class="bd">' + o.cuerpo + '</div>' +
        (o.pie ? '<footer class="ft">' + o.pie + '</footer>' : '') + '</div>', 'esquina');
    }
    var nSel = P.actividades.filter(function (a, i) { return E.sel[i] !== false; }).length;
    var chips = '<div class="chips"><span class="chip">Categoría <b>' + esc(catsTexto()) + '</b></span>' +
      '<span class="chip"><b>' + esc(P.evaluacion) + '</b></span>' +
      '<span class="chip"><b>' + nSel + '</b> de ' + P.actividades.length + ' actividades</span>' +
      '<span class="chip"><b>' + P.alumnos.length + '</b> alumnos/as</span></div>';

    // ---- En reposo: tarjeta de la esquina ----
    if (!F && !verFin) {
      var descartando = Date.now() - confirmarDescarte < 4000;
      return poner('<div class="card" role="dialog" aria-label="iAsistente → Séneca">' + cabecera('Notas y actividades') + tabsHtml('notas', P, V) +
        '<div class="bd">' + resultadoHtml(E.resultado) +
          '<p class="eti">Desde iAsistente</p><h3 class="clase">' + esc(P.clase || '') + '</h3>' + chips +
          '<p class="sub">Si una categoría no existe en tu cuaderno de Séneca, la crearé con ese nombre. Para usar las tuyas, ' +
          'cópialas en iAsistente desde Séneca (Alumnado → Cuaderno de clase → Parámetros → Categoría).</p>' +
          (grupoDeClase() ? '<div class="grp">Grupo en Séneca: <b>' + esc(grupoDeClase().desc) + '</b>' +
            '<button class="lnk" data-a="cambiarGrupo">Cambiar</button></div>' : '') +
          seleccionHtml() +
          registroHtml() + '</div>' +
        '<footer class="ft"><button class="btn ' + (descartando ? 'peligro' : 'fant') + '" data-a="descartar">' + ico('papelera') +
          (descartando ? '¿Seguro?' : 'Descartar datos') + '</button><span class="sp"></span>' +
          '<button class="btn pri" data-a="empezar"' + (nSel ? '' : ' disabled') + '>Empezar' + ico('flecha') + '</button></footer></div>', 'esquina');
    }

    // ---- Terminado: resultado ----
    if (!F && verFin) {
      var r = E.resultado || { guardadas: 0, iguales: 0, avisos: 0 };
      return poner('<div class="dlg" role="dialog" aria-label="Volcado terminado">' + cabecera(P.clase || '') + pasosHtml(5) +
        '<div class="barra" data-fijo><i style="width:100%"></i></div><div class="bd"><div class="trab fin">' +
          '<div class="ok">' + ico('check') + '</div><h3>Notas volcadas en Séneca</h3>' +
          '<p>Grupo «' + esc(E.grupo ? E.grupo.desc : '') + '» · categoría «' + esc(catsTexto()) + '». El cuaderno ya muestra las notas.</p>' +
          '<div class="cifras"><div class="cifra"><b>' + r.guardadas + '</b><span>guardadas</span></div>' +
            '<div class="cifra"><b>' + r.iguales + '</b><span>ya estaban</span></div>' +
            '<div class="cifra' + (r.avisos ? ' av' : '') + '"><b>' + r.avisos + '</b><span>avisos</span></div></div>' +
          (ahorro(r) ? '<p class="ahorro">' + ico('reloj') + '<span>Te has ahorrado unos <b>' + ahorro(r) + ' min</b> de hacerlo a mano.</span></p>' : '') +
        '</div>' + registroHtml() + '</div>' +
        '<footer class="ft"><span class="sp"></span><button class="btn pri" data-a="finOk">Hecho' + ico('check') + '</button></footer></div>', 'centro', 100);
    }

    // ---- En marcha: diálogo centrado ----
    var paso = PASOS[F.fase], cuerpo, pie;
    if (F.parado) {
      cuerpo = '<p class="tit">Me he detenido</p><p class="sub">Puedes reintentar: vuelvo sola a la pantalla que tocaba.</p>' +
        '<div class="err">' + ico('alerta') + '<span>' + esc(F.parado) + '</span></div>';
      pie = '<button class="btn fant" data-a="informe">' + ico('correo') + 'Informar del fallo</button><span class="sp"></span>' +
        '<button class="btn sec" data-a="cancelar">Cancelar</button><button class="btn pri" data-a="reintentar">' + ico('reintentar') + 'Reintentar</button>';
    } else if (F.fase === 'eligeGrupo') {
      var gs = leerGrupos(), sug = sugerirGrupo(gs);
      if (grupoElegido == null && sug >= 0) grupoElegido = sug;
      cuerpo = '<p class="tit">¿En qué grupo vuelco las notas?</p><p class="sub">Tus grupos en Séneca. iAsistente tiene ' + P.alumnos.length + ' alumnos/as en esta clase' +
        (sug >= 0 ? '; te sugiero uno por alumnado, grupo y materia: revísalo.' : '.') + '</p>' +
        '<div class="grupos" role="radiogroup">' + gs.map(function (g, k) {
          var dif = g.n != null && g.n !== P.alumnos.length;
          return '<label class="gc' + (k === grupoElegido ? ' sel' : '') + '"><input type="radio" name="g" data-a="grupo" value="' + k + '"' +
            (k === grupoElegido ? ' checked' : '') + '><b>' + esc(g.desc) + '</b>' + (g.propia ? '<small>' + esc(sinAlumnos(g.texto)) + '</small>' : '') +
            (g.n != null ? '<span class="n' + (dif ? ' dif' : '') + '" title="' + g.n + ' alumnos/as en Séneca' +
              (dif ? ' (en iAsistente, ' + P.alumnos.length + ')' : '') + '">' + ico('persona') + g.n + '</span>' : '') +
            (k === sug ? '<span class="sug">Sugerido</span>' : '') + '</label>';
        }).join('') + '</div>';
      pie = '<button class="btn sec" data-a="cancelar">Cancelar</button><button class="btn pri" data-a="continuar"' +
        (grupoElegido == null ? ' disabled' : '') + '>Continuar' + ico('flecha') + '</button>';
    } else if (F.fase === 'confirmar') {
      var fil = F.filas || [];
      cuerpo = '<p class="tit">¿Creo estas actividades en Séneca?</p><p class="sub">No las encuentro en Séneca con el mismo nombre ni con la misma descripción corta. ' +
        'Si alguna ya está (con otro nombre), elige cuál es: no se duplica y sus notas van a esa. «No subir» la deja fuera, sin notas.</p>' +
        '<table class="par">' + F.faltan.map(function (x, k) {
          var a = P.actividades[x.i], orden = x.sim.concat(fil.map(function (f, j) { return j; }).filter(function (j) { return x.sim.indexOf(j) < 0; }));
          return '<tr><td><b>' + esc(a.nombre) + '</b>' + (x.sim.length ? '<br><small class="dif">⚠ Se parece a «' + esc(fil[x.sim[0]].desc) + '»</small>' : '') + '</td>' +
            '<td><select data-a="conf" data-k="' + k + '" aria-label="Qué hacer con ' + esc(a.nombre) + '">' +
            (x.op === '' ? '<option value="" selected>— elige —</option>' : '') +
            '<option value="crear"' + (x.op === 'crear' ? ' selected' : '') + '>Crear nueva en Séneca</option>' +
            '<option value="no"' + (x.op === 'no' ? ' selected' : '') + '>No subir</option>' +
            orden.map(function (j) {
              return '<option value="f' + j + '"' + (x.op === 'f' + j ? ' selected' : '') + '>Ya está: ' + esc(fil[j].desc.slice(0, 60)) +
                (fil[j].corto ? ' (' + esc(fil[j].corto) + ')' : '') + '</option>';
            }).join('') + '</select></td></tr>';
        }).join('') + '</table>';
      var pend = F.faltan.some(function (x) { return !x.op; });
      pie = '<button class="btn sec" data-a="cancelar">Cancelar</button><button class="btn pri" data-a="confOk"' + (pend ? ' disabled' : '') + '>Continuar' + ico('flecha') + '</button>';
    } else if (F.fase === 'cotejo') {
      cuerpo = '<p class="tit">Empareja el alumnado</p><p class="sub">Estos nombres no coinciden entre iAsistente y Séneca. Elige quién es quién, o «no volcar».</p>' +
        '<table class="par">' + F.sinE.map(function (x, k) {
          return '<tr><td>' + esc(P.alumnos[x.i]) + '</td><td><select data-a="par" data-k="' + k + '" aria-label="Pareja en Séneca de ' + esc(P.alumnos[x.i]) + '">' +
            '<option value="">— no volcar —</option>' + F.sinS.map(function (s2) {
              return '<option' + (s2 === x.sel ? ' selected' : '') + ' value="' + esc(s2) + '">' + esc(s2) + '</option>';
            }).join('') + '</select></td></tr>';
        }).join('') + '</table>' +
        (F.sinS.length ? '<p class="nota">En Séneca sin pareja: ' + esc(F.sinS.join('; ')) + '</p>' : '');
      pie = '<button class="btn sec" data-a="cancelar">Cancelar</button><button class="btn pri" data-a="cotejoOk">Continuar' + ico('flecha') + '</button>';
    } else {
      var q = queHace(F);
      cuerpo = '<div class="queh"><div class="anillo" data-fijo role="progressbar" aria-label="Trabajando"></div><div><h3>' + esc(q[0]) + '</h3><p>' + esc(q[1]) + '</p></div></div>' +
        vivoHtml(F) + '<p class="consejo">' + ico('bombilla') + esc(CONSEJOS[Math.floor(Date.now() / 7000) % CONSEJOS.length]) + '</p>';
      pie = '<span class="sp"></span><button class="btn sec" data-a="cancelar">Detener</button>';
    }
    poner('<div class="dlg" role="dialog" aria-modal="true" aria-label="iAsistente → Séneca">' + cabecera(P.clase || '') + pasosHtml(paso, !!F.parado) +
      '<div class="barra" data-fijo><i></i></div><div class="bd">' + cuerpo + registroHtml() + '</div>' +
      '<footer class="ft">' + (pie.indexOf('class="sp"') < 0 ? '<span class="sp"></span>' : '') + pie + '</footer></div>',
      'centro', Math.round(avance(paso) * 100));
  }

  window.__iasPintar = pintar; // observaciones.js avisa así de sus cambios

  C.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-a]'), a = el && el.getAttribute('data-a');
    if (!a) return;
    if (a === 'abrir' || a === 'cerrar') { E.abierto = a === 'abrir'; guardar(); pintar(); }
    else if (a === 'empezar') { verFin = false; empezar(); }
    else if (a === 'finOk') { verFin = false; pintar(); }
    else if (a === 'cambiarGrupo') { delete E.grupos[claveClase()]; E.grupo = null; E.cotejado = ''; guardar(); pintar(); }
    else if (a === 'continuar') {
      var g = leerGrupos()[grupoElegido];
      if (!g) return;
      E.grupo = E.grupos[claveClase()] = { desc: g.desc, texto: g.texto, n: g.n };
      log('Grupo: «' + g.desc + '».');
      trasGrupo(); avanzar();
    } else if (a === 'cotejoOk') {
      var Fc = E.flujo, n = 0;
      Fc.sinE.forEach(function (x) { if (x.sel) { E.mapa[claveNombre(x.sel)] = x.i; n++; } });
      log('Emparejados a mano: ' + n + (Fc.sinE.length - n ? '; sin volcar: ' + (Fc.sinE.length - n) : '') + '.');
      E.cotejado = firmaCotejo();
      fase('irActs'); avanzar();
    } else if (a === 'reintentar') {
      // Si el docente se ha movido de pantalla, se vuelve a navegar al paso que tocaba.
      var VOLVER = { cargarGrupos: 'irGrupos', eligeGrupo: 'irGrupos', alumnos: 'irAlumnos', cat: 'irParam', catForm: 'irParam', catTras: 'irParam',
        acts: 'irActs', confirmar: 'irActs', actForm: 'irActs', actTras: 'irActs', notas: 'irNotas' };
      fase(VOLVER[E.flujo.fase] || E.flujo.fase); avanzar(); pintar();
    }
    else if (a === 'cancelar') { fase(null); log('Detenido.'); }
    else if (a === 'tab') { E.modo = el.getAttribute('data-t'); chrome.storage.local.set({ modo: E.modo }); pintar(); }
    else if (a === 'obsEmpezar') obsAccion('empezar');
    else if (a === 'obsReintentar') obsAccion('reintentar');
    else if (a === 'obsCancelar') obsAccion('cancelar');
    else if (a === 'obsDescartar') obsAccion('descartar');
    else if (a === 'confOk') {
      var Fq = E.flujo, n2 = { crear: 0, no: 0, ya: 0 };
      Fq.faltan.forEach(function (x) {
        var a2 = E.paquete.actividades[x.i];
        if (x.op === 'no') { E.progreso.acts[x.i] = 'omitida'; n2.no++; }
        else if (x.op && x.op.charAt(0) === 'f') {
          var f2 = Fq.filas[+x.op.slice(1)];
          E.progreso.acts[x.i] = 'existia'; n2.ya++;
          if (f2 && f2.corto) E.cortos[claveCorto(a2)] = f2.corto; // sus notas, a esa columna
          log('«' + a2.nombre + '» = «' + (f2 ? f2.desc : '?') + '» (ya estaba).');
        } else n2.crear++;
      });
      log('Confirmado: ' + n2.crear + ' a crear, ' + n2.ya + ' ya estaban, ' + n2.no + ' sin subir.');
      E.progreso.confirmado = true;
      fase('acts', { refrescado: Date.now() - 3000 }); avanzar();
    }
    else if (a === 'informe') informar();
    else if (a === 'avisoOk') { avisoVisto = true; pintar(); }
    else if (a === 'descartar') {
      // Doble clic de confirmación en el propio botón, en lugar de un confirm() del navegador.
      if (Date.now() - confirmarDescarte > 4000) { confirmarDescarte = Date.now(); pintar(); return setTimeout(pintar, 4100); }
      E.paquete = null; E.flujo = null; E.log = []; E.resultado = null;
      chrome.storage.local.remove(['paquete', 'progreso', 'log', 'flujo', 'resultado']); pintar();
    }
  });
  C.addEventListener('change', function (ev) {
    var a = ev.target.getAttribute('data-a');
    if (a === 'grupo') { grupoElegido = +ev.target.value; pintar(); }
    else if (a === 'par') { E.flujo.sinE[+ev.target.getAttribute('data-k')].sel = ev.target.value; guardar(); }
    else if (a === 'obsSel') obsAccion('sel', { clave: ev.target.getAttribute('data-k'), on: ev.target.checked });
    else if (a === 'obsTodos') obsAccion('todos', { on: ev.target.checked });
    else if (a === 'conf') { E.flujo.faltan[+ev.target.getAttribute('data-k')].op = ev.target.value; guardar(); pintar(); }
    else if (a === 'selAct') { E.sel[+ev.target.getAttribute('data-i')] = ev.target.checked ? true : false; guardar(); pintar(); }
    else if (a === 'selGrupo') {
      var on = ev.target.checked;
      gruposCat()[+ev.target.getAttribute('data-g')].ids.forEach(function (i) { E.sel[i] = on; });
      guardar(); pintar();
    }
  });
  C.addEventListener('toggle', function (ev) {
    if (ev.target.classList.contains('selw')) selAbierta = ev.target.open;
    else if (ev.target.classList.contains('reg')) regAbierto = ev.target.open;
  }, true);
  // En reposo, un clic fuera de la tarjeta la minimiza.
  document.addEventListener('mousedown', function (ev) {
    var V2 = obsVista();
    if (E.abierto && (E.paquete || V2) && !E.flujo && !(V2 && V2.enMarcha) && !verFin && ev.composedPath().indexOf(host) < 0) { E.abierto = false; guardar(); pintar(); }
  }, true);
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && E.abierto && (E.paquete || obsVista()) && !E.flujo) { verFin = false; E.abierto = false; guardar(); pintar(); }
  });

  // Séneca cambia de pantalla sin recargar: se observa el DOM (con respiro).
  var t = null;
  function tick() { clearTimeout(t); t = setTimeout(function () { avanzar(); pintar(); }, 700); }
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area === 'local' && ch.paquete) cargar(function () { E.abierto = !!E.paquete; pintar(); });
    else if (area === 'local' && ch.modo) { E.modo = ch.modo.newValue || 'notas'; E.abierto = true; pintar(); }
    if (area === 'local' && ch.instrumentoDefecto) E.instrDef = ch.instrumentoDefecto.newValue || '';
  });
  cargar(function () {
    pintar();
    new MutationObserver(tick).observe(document.documentElement, { childList: true, subtree: true });
    // Reloj del recorrido. Con la pestaña en segundo plano Chrome frena los
    // temporizadores de la página (hasta uno por minuto), y el recorrido se
    // detenía; los de un worker no sufren ese freno. Si la página no permite
    // workers, se usa setInterval. Al volver a la pestaña se avanza al momento.
    var latido = function () { if (E.flujo && !E.flujo.parado && !poniendo) { avanzar(); pintar(); } };
    try {
      var w = new Worker(URL.createObjectURL(new Blob(['setInterval(function(){postMessage(0)},1500)'], { type: 'text/javascript' })));
      w.onmessage = latido;
    } catch (e) { setInterval(latido, 1500); }
    document.addEventListener('visibilitychange', function () { if (!document.hidden) latido(); });
    tick();
  });
})();
