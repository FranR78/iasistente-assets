/*
 * iAsistente → Séneca: OBSERVACIONES. Vuelca en «Mis observaciones» de cada
 * alumno/a el texto que manda iAsistente (paquete tipo 'observaciones'),
 * marcado «Compartir». Se arranca en la pantalla Registro de observaciones del
 * primer alumno (Mis alumnos y alumnas → grupo → ⋮ → Mis observaciones) y avanza
 * sola con la flecha «siguiente alumno» de Séneca. Nunca borra nada y no repite
 * una observación que ya esté en el listado del alumno.
 * Habla con seneca-main.js (mundo de la página) para llamar a aceptar() y pasarAntSig().
 * No pinta nada: su pestaña «Observaciones» la dibuja el panel de seneca.js (window.__iasObs).
 */
(function () {
  'use strict';
  if (window.top !== window) return;

  var $ = function (sel) { return document.querySelector(sel); };
  function norm(s) {
    return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/[^a-z0-9ñ]+/g, ' ').trim();
  }
  function claveNombre(s) { return norm(s).split(' ').filter(Boolean).sort().join(' '); }
  function textoSel(sel) { return sel && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex].text : ''; }

  // ---------- puente con seneca-main.js ----------
  var seq = 0, esperas = {};
  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (ev.source !== window || !d || d.iasSenecaMain !== 'res' || d.ext !== chrome.runtime.id || !esperas[d.id]) return;
    var e = esperas[d.id]; delete esperas[d.id];
    if (d.ok) e.ok(d.data); else e.ko(new Error(d.error));
  });
  function llamar(fn, args) {
    return new Promise(function (ok, ko) {
      var id = 'o' + (++seq);
      esperas[id] = { ok: ok, ko: ko };
      setTimeout(function () { if (esperas[id]) { delete esperas[id]; ko(new Error('Séneca no ha respondido.')); } }, 30000);
      window.postMessage({ iasSenecaMain: 'cmd', ext: chrome.runtime.id, id: id, op: 'llamar', args: { fn: fn, args: args || [] } }, '*');
    });
  }

  // ---------- estado ----------
  // obsPaquete: { clase, evaluacion, alumnos[], textos[] } · obsHechos: {clave: 'guardada'|'existia'|'sin texto'}
  // obsFlujo: null | { accion: null | {tipo:'guardar'|'siguiente', clave, valor, desde}, parado }
  // obsSel: {clave: false} = no subir ese alumno/a
  var S = { paquete: null, hechos: {}, flujo: null, log: [], sel: {} };
  var CLAVES = ['obsPaquete', 'obsHechos', 'obsFlujo', 'obsLog', 'obsSel'];
  function cargar(cb) {
    chrome.storage.local.get(CLAVES, function (r) {
      S.paquete = r.obsPaquete || null; S.hechos = r.obsHechos || {}; S.flujo = r.obsFlujo || null; S.log = r.obsLog || [];
      S.sel = r.obsSel || {};
      cb();
    });
  }
  function guardar() { chrome.storage.local.set({ obsHechos: S.hechos, obsFlujo: S.flujo, obsLog: S.log.slice(-40), obsSel: S.sel }); }
  function log(m) { S.log.push(new Date().toTimeString().slice(0, 5) + ': ' + m); guardar(); pintar(); }
  function parar(m) { if (S.flujo) S.flujo.parado = m; log('✗ ' + m); }

  // ---------- pantalla ----------
  function enPantalla() { return !!($('[name="TEXTO_1"]') && $('[name="COMBO_REGISTROS_"]')); }
  function alumnoActual() {
    var sel = $('[name="COMBO_REGISTROS_"]');
    return sel ? { nombre: textoSel(sel).replace(/-[^-]*$/, '').trim(), valor: sel.value } : null;
  }
  function textoDe(nombre) {
    var P = S.paquete, k = claveNombre(nombre);
    for (var i = 0; i < P.alumnos.length; i++) if (claveNombre(P.alumnos[i]) === k) return P.textos[i] || '';
    return null; // no está en iAsistente
  }
  /** ¿Ya está ese texto en «Listado de observaciones creadas»? (Séneca puede recortarlo) */
  function yaEnListado(texto) {
    var t = norm(texto).slice(0, 60);
    return !!t && [].some.call(document.querySelectorAll('td'), function (td) {
      var x = norm(td.textContent);
      return x.length >= Math.min(20, t.length) && (x.indexOf(t) === 0 || t.indexOf(x) === 0);
    });
  }

  // ---------- recorrido ----------
  function paso() {
    var F = S.flujo;
    if (!F || F.parado || !S.paquete || !enPantalla()) return;
    var acc = $('[name="COMBO_ACCIONES_"]');
    if (acc && !/observaciones/i.test(textoSel(acc))) return parar('La acción elegida en Séneca no es «Mis observaciones».');
    var al = alumnoActual(), A = F.accion;
    if (A && A.tipo === 'siguiente') {
      if (al.valor !== A.valor) { F.accion = null; guardar(); }
      else if (Date.now() - A.desde > 8000) { F.accion = null; return fin(); } // no hay siguiente: era el último
      else return;
    }
    if (A && A.tipo === 'guardar') {
      if (Date.now() - A.desde < 1500) return;
      if (yaEnListado(A.texto)) {
        S.hechos[A.clave] = 'guardada'; log('✓ ' + al.nombre + ': guardada.'); F.accion = null; guardar();
        return pendientes() ? siguiente(al) : fin();
      }
      if (Date.now() - A.desde > 12000) return parar(al.nombre + ': Séneca no ha guardado la observación (mira si muestra algún aviso) y pulsa Reintentar.');
      return;
    }
    // Al pasar del último, la flecha de Séneca vuelve al primero: alumno ya visitado = vuelta completa.
    F.vistos = F.vistos || {};
    if (F.vistos[al.valor]) return fin();
    F.vistos[al.valor] = 1; guardar();
    var clave = claveNombre(al.nombre);
    if (S.hechos[clave] || S.sel[clave] === false) return pendientes() ? siguiente(al) : fin(); // hecho, o no elegido
    var texto = textoDe(al.nombre);
    if (texto === null) { S.hechos[clave] = 'no está'; log('· ' + al.nombre + ': no está en iAsistente.'); return siguiente(al); }
    if (!texto) { S.hechos[clave] = 'sin texto'; log('· ' + al.nombre + ': sin texto.'); return siguiente(al); }
    if (yaEnListado(texto)) { S.hechos[clave] = 'existia'; log('· ' + al.nombre + ': ya estaba.'); return siguiente(al); }
    // Rellenar y guardar.
    var ta = $('[name="TEXTO_1"]');
    ta.value = texto.slice(0, ta.maxLength > 0 ? ta.maxLength : 4000);
    ta.dispatchEvent(new Event('input', { bubbles: true })); ta.dispatchEvent(new Event('change', { bubbles: true }));
    var comp = $('[name="COMPARTIR_1"]');
    if (comp && !comp.checked) comp.click();
    var ev = $('[name="EVALUACIONES_1"]');
    if (ev && S.paquete.evaluacion) {
      var o = [].filter.call(ev.options, function (x) { return norm(x.text).indexOf(norm(S.paquete.evaluacion)) === 0; })[0];
      if (o) { ev.value = o.value; ev.dispatchEvent(new Event('change', { bubbles: true })); }
      else log('⚠ ' + al.nombre + ': no encuentro «' + S.paquete.evaluacion + '» en Evaluación; la dejo sin elegir.');
    }
    F.accion = { tipo: 'guardar', clave: clave, texto: texto, desde: Date.now() }; guardar();
    llamar('aceptar').catch(function (e) { parar(e.message); });
  }
  function siguiente(al) {
    S.flujo.accion = { tipo: 'siguiente', valor: al.valor, desde: Date.now() }; guardar(); pintar();
    llamar('pasarAntSig', [true]).catch(function (e) { parar(e.message); });
  }
  /** ¿Queda algún alumno/a elegido, con texto, sin hacer? */
  function pendientes() {
    var P = S.paquete;
    return P.alumnos.some(function (a, i) { var k = claveNombre(a); return P.textos[i] && S.sel[k] !== false && !S.hechos[k]; });
  }
  function fin() {
    var n = Object.keys(S.hechos).filter(function (k) { return S.hechos[k] === 'guardada'; }).length;
    S.flujo = null; log('✓ Terminado: ' + n + ' observación(es) guardadas.');
  }

  // ---------- datos para el panel ----------
  // El panel es uno solo (seneca.js, pestaña «Observaciones»): los content scripts de la
  // extensión comparten mundo aislado, así que aquí solo se exponen datos y acciones.
  function pintar() { if (typeof window.__iasPintar === 'function') window.__iasPintar(); }
  function vista() {
    var P = S.paquete, F = S.flujo;
    if (!P) return null;
    var alumnos = [], n = 0;
    P.alumnos.forEach(function (a, i) {
      if (!P.textos[i]) return;
      var k = claveNombre(a), sel = S.sel[k] !== false;
      alumnos.push({ nombre: a, clave: k, sel: sel, hecho: S.hechos[k] || '' });
      if (sel) n++;
    });
    var hechas = Object.keys(S.hechos).filter(function (k) { return S.hechos[k] === 'guardada' || S.hechos[k] === 'existia'; }).length;
    return { clase: P.clase, evaluacion: P.evaluacion, alumnos: alumnos, n: n, hechas: hechas, enPantalla: enPantalla(),
      enMarcha: !!F, parado: (F && F.parado) || '', actual: (alumnoActual() || {}).nombre || '', log: S.log.slice(-40) };
  }
  function accion(a, arg) {
    if (a === 'empezar') { S.flujo = { accion: null }; log('Empiezo en ' + (alumnoActual() || {}).nombre + '.'); tick(); }
    else if (a === 'reintentar') { S.flujo.parado = null; S.flujo.accion = null; guardar(); pintar(); tick(); }
    else if (a === 'cancelar') { S.flujo = null; log('Parado.'); }
    else if (a === 'descartar') {
      chrome.storage.local.remove(['obsPaquete', 'obsHechos', 'obsFlujo', 'obsLog', 'obsSel']);
      S.paquete = null; S.hechos = {}; S.log = []; S.flujo = null; pintar();
    }
    else if (a === 'sel') { S.sel[arg.clave] = arg.on; guardar(); pintar(); }
    else if (a === 'todos') {
      S.paquete.alumnos.forEach(function (al, i) { if (S.paquete.textos[i]) S.sel[claveNombre(al)] = arg.on; });
      guardar(); pintar();
    }
  }
  window.__iasObs = { vista: vista, accion: accion };

  var t = null;
  function tick() { clearTimeout(t); t = setTimeout(function () { paso(); pintar(); }, 700); }
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area === 'local' && ch.obsPaquete) cargar(pintar);
  });
  cargar(function () {
    pintar();
    new MutationObserver(tick).observe(document.documentElement, { childList: true, subtree: true });
    setInterval(tick, 2000); // por si Séneca no cambia el DOM mientras se espera
  });
})();
