/* Opciones de la extensión: instrumento de evaluación por defecto (chrome.storage.local). */
(function () {
  'use strict';
  var inp = document.getElementById('instr'), ok = document.getElementById('ok');
  chrome.storage.local.get(['instrumentoDefecto'], function (r) { inp.value = r.instrumentoDefecto || ''; });
  document.getElementById('guardar').addEventListener('click', function () {
    chrome.storage.local.set({ instrumentoDefecto: inp.value.trim() }, function () {
      ok.textContent = chrome.runtime.lastError ? 'No se ha podido guardar' : 'Guardado ✓';
      setTimeout(function () { ok.textContent = ''; }, 2000);
    });
  });
})();
