/*
 * Puente con iAsistente (basado en el de Evaluanda → Séneca). Corre en los iframes
 * de googleusercontent.com (donde Apps Script sirve la app) y solo actúa si la
 * página es iAsistente (tiene #ias-seneca-marca). Se comunica por atributos del
 * <html>, revisados cada medio segundo (Apps Script reescribe el documento al
 * cargarlo y eso borra los listeners, así que postMessage no sirve aquí).
 *   data-ias-seneca="<versión>"  ← lo pone la extensión (está instalada)
 *   data-ias-seneca-paquete      ← lo deja iAsistente (JSON)
 *   data-ias-seneca-recibido     ← responde la extensión ('ok' | 'ko')
 */
(function () {
  'use strict';
  var VERSION = chrome.runtime.getManifest().version;
  // Si conviven la copia de la Chrome Web Store y otra instalada a mano, solo atiende la oficial.
  var OFICIAL = !!chrome.runtime.getManifest().update_url;

  function valido(p) {
    if (p && p.v === 1 && p.tipo === 'observaciones') {
      return Array.isArray(p.alumnos) && Array.isArray(p.textos) && p.alumnos.length === p.textos.length;
    }
    return p && p.v === 1 && Array.isArray(p.alumnos) && Array.isArray(p.actividades) &&
      p.actividades.length > 0 && p.categoria && typeof p.categoria.descripcion === 'string';
  }

  function revisar() {
    var r = document.documentElement;
    // Extensión recargada o actualizada: este puente ya no puede hablar con ella. Se quita
    // la marca para que iAsistente diga «no detecto la extensión» (hay que recargar la página).
    if (!chrome.runtime || !chrome.runtime.id) {
      if (r) r.removeAttribute('data-ias-seneca');
      return clearInterval(reloj);
    }
    if (!r || !document.getElementById('ias-seneca-marca')) return;
    if (OFICIAL) { if (!r.hasAttribute('data-ias-seneca-oficial')) r.setAttribute('data-ias-seneca-oficial', '1'); }
    else if (r.hasAttribute('data-ias-seneca-oficial')) return;
    if (r.getAttribute('data-ias-seneca') !== VERSION) r.setAttribute('data-ias-seneca', VERSION);
    var txt = r.getAttribute('data-ias-seneca-paquete');
    if (!txt || r.hasAttribute('data-ias-seneca-recibido')) return;
    r.removeAttribute('data-ias-seneca-paquete');
    var p = null;
    try { p = JSON.parse(txt); } catch (e) { /* JSON roto: se responde 'ko' */ }
    if (!valido(p)) return r.setAttribute('data-ias-seneca-recibido', 'ko');
    try {
      // Paquete nuevo = progreso nuevo: se descarta lo hecho con el anterior.
      // Notas y observaciones conviven; `modo` (el interruptor del panel en Séneca) pasa a
      // lo último que se ha mandado, y la selección de qué subir vuelve a «todo».
      var datos = p.tipo === 'observaciones'
        ? { obsPaquete: p, obsHechos: {}, obsFlujo: null, obsLog: [], obsSel: {}, modo: 'observaciones' }
        : { paquete: p, progreso: { acts: {} }, log: [], flujo: null, sel: {}, modo: 'notas' };
      chrome.storage.local.set(datos, function () {
        r.setAttribute('data-ias-seneca-recibido', chrome.runtime.lastError ? 'ko' : 'ok');
      });
    } catch (e) {
      r.removeAttribute('data-ias-seneca');
      r.setAttribute('data-ias-seneca-recibido', 'recargar');
    }
  }

  var reloj = setInterval(revisar, 500);
})();
